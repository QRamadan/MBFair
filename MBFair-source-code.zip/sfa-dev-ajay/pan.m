#define rand	pan_rand
#define pthread_equal(a,b)	((a)==(b))
#if defined(HAS_CODE) && defined(VERBOSE)
	#ifdef BFS_PAR
		bfs_printf("Pr: %d Tr: %d\n", II, t->forw);
	#else
		cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
	#endif
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* CLAIM formula2 */
	case 3: // STATE 1 - _spin_nvr.tmp:3 - [(!((CustomerProfile_freeDelivery==0)))] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported1 = 0;
			if (verbose && !reported1)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported1 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[10][1] = 1;
		if (!( !((((int)now.CustomerProfile_freeDelivery)==0))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 4: // STATE 13 - _spin_nvr.tmp:10 - [-end-] (0:0:0 - 1)
		
#if defined(VERI) && !defined(NP)
#if NCLAIMS>1
		{	static int reported13 = 0;
			if (verbose && !reported13)
			{	int nn = (int) ((Pclaim *)pptr(0))->_n;
				printf("depth %ld: Claim %s (%d), state %d (line %d)\n",
					depth, procname[spin_c_typ[nn]], nn, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported13 = 1;
				fflush(stdout);
		}	}
#else
		{	static int reported13 = 0;
			if (verbose && !reported13)
			{	printf("depth %d: Claim, state %d (line %d)\n",
					(int) depth, (int) ((Pclaim *)pptr(0))->_p, src_claim[ (int) ((Pclaim *)pptr(0))->_p ]);
				reported13 = 1;
				fflush(stdout);
		}	}
#endif
#endif
		reached[10][13] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC :init: */
	case 5: // STATE 1 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1059 - [(run Customer(1,1,1))] (0:0:0 - 1)
		IfNotBlocked
		reached[9][1] = 1;
		if (!(addproc(II, 1, 4, 1, 1, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 6: // STATE 2 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1060 - [(run CustomerProfile(1,1,1))] (0:0:0 - 1)
		IfNotBlocked
		reached[9][2] = 1;
		if (!(addproc(II, 1, 7, 1, 1, 1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 7: // STATE 4 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1063 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[9][4] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC WebUser */
	case 8: // STATE 1 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:979 - [role = initialiser_role0] (0:7:2 - 1)
		IfNotBlocked
		reached[8][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P8 *)_this)->role);
		((P8 *)_this)->role = ((int)((P8 *)_this)->initialiser_role0);
#ifdef VAR_RANGES
		logval("WebUser:role", ((int)((P8 *)_this)->role));
#endif
		;
		/* merge: state0 = 1(7, 2, 7) */
		reached[8][2] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P8 *)_this)->state0);
		((P8 *)_this)->state0 = 1;
#ifdef VAR_RANGES
		logval("WebUser:state0", ((int)((P8 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 9: // STATE 3 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:982 - [((WebUser_performLoginAction==1))] (57:0:1 - 1)
		IfNotBlocked
		reached[8][3] = 1;
		if (!((((int)now.WebUser_performLoginAction)==1)))
			continue;
		/* merge: state0_transition = 1(57, 4, 57) */
		reached[8][4] = 1;
		(trpt+1)->bup.oval = ((int)((P8 *)_this)->state0_transition);
		((P8 *)_this)->state0_transition = 1;
#ifdef VAR_RANGES
		logval("WebUser:state0_transition", ((int)((P8 *)_this)->state0_transition));
#endif
		;
		/* merge: .(goto)(57, 8, 57) */
		reached[8][8] = 1;
		;
		/* merge: goto transitionFiring(0, 9, 57) */
		reached[8][9] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 10: // STATE 8 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:987 - [.(goto)] (0:57:0 - 2)
		IfNotBlocked
		reached[8][8] = 1;
		;
		/* merge: goto transitionFiring(0, 9, 57) */
		reached[8][9] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 11: // STATE 6 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:985 - [assert(0)] (0:57:0 - 1)
		IfNotBlocked
		reached[8][6] = 1;
		spin_assert(0, "0", II, tt, t);
		/* merge: .(goto)(57, 8, 57) */
		reached[8][8] = 1;
		;
		/* merge: goto transitionFiring(0, 9, 57) */
		reached[8][9] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 12: // STATE 11 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:990 - [current_event = 0] (0:0:1 - 3)
		IfNotBlocked
		reached[8][11] = 1;
		(trpt+1)->bup.oval = ((int)((P8 *)_this)->current_event);
		((P8 *)_this)->current_event = 0;
#ifdef VAR_RANGES
		logval("WebUser:current_event", ((int)((P8 *)_this)->current_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 13: // STATE 12 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:992 - [(internal_queue?[current_event])] (0:0:0 - 1)
		IfNotBlocked
		reached[8][12] = 1;
		if (!(
#ifndef XUSAFE
		(!(q_claim[((P8 *)_this)->internal_queue]&1) || q_R_check(((P8 *)_this)->internal_queue, II)) &&
		(!(q_claim[((P8 *)_this)->internal_queue]&2) || q_S_check(((P8 *)_this)->internal_queue, II)) &&
#endif
		not_RV(((P8 *)_this)->internal_queue) && \
		(q_len(((P8 *)_this)->internal_queue) > 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 14: // STATE 13 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:993 - [internal_queue?current_event] (0:0:1 - 1)
		reached[8][13] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P8 *)_this)->internal_queue]&1)
		{	q_R_check(((P8 *)_this)->internal_queue, II);
		}
#endif
		if (q_zero(((P8 *)_this)->internal_queue))
		{	if (boq != ((P8 *)_this)->internal_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P8 *)_this)->internal_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.oval = ((int)((P8 *)_this)->current_event);
		;
		((P8 *)_this)->current_event = qrecv(((P8 *)_this)->internal_queue, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("WebUser:current_event", ((int)((P8 *)_this)->current_event));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P8 *)_this)->internal_queue);
			sprintf(simtmp, "%d", ((int)((P8 *)_this)->current_event)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P8 *)_this)->internal_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 15: // STATE 15 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:995 - [event_queue?current_event,ack_out] (0:0:2 - 1)
		reached[8][15] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P8 *)_this)->event_queue]&1)
		{	q_R_check(((P8 *)_this)->event_queue, II);
		}
#endif
		if (q_zero(((P8 *)_this)->event_queue))
		{	if (boq != ((P8 *)_this)->event_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P8 *)_this)->event_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P8 *)_this)->current_event);
		(trpt+1)->bup.ovals[1] = ((P8 *)_this)->ack_out;
		;
		((P8 *)_this)->current_event = qrecv(((P8 *)_this)->event_queue, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("WebUser:current_event", ((int)((P8 *)_this)->current_event));
#endif
		;
		((P8 *)_this)->ack_out = qrecv(((P8 *)_this)->event_queue, XX-1, 1, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P8 *)_this)->event_queue);
			sprintf(simtmp, "%d", ((int)((P8 *)_this)->current_event)); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((P8 *)_this)->ack_out); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P8 *)_this)->event_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 16: // STATE 18 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:999 - [(((state0==2)&&(current_event==1)))] (22:0:5 - 1)
		IfNotBlocked
		reached[8][18] = 1;
		if (!(((((int)((P8 *)_this)->state0)==2)&&(((int)((P8 *)_this)->current_event)==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0 */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P8 *)_this)->state0;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P8 *)_this)->state0 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P8 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P8 *)_this)->current_event = 0;
		/* merge: state0 = 0(22, 19, 22) */
		reached[8][19] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P8 *)_this)->state0);
		((P8 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("WebUser:state0", ((int)((P8 *)_this)->state0));
#endif
		;
		/* merge: state0 = 3(22, 20, 22) */
		reached[8][20] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P8 *)_this)->state0);
		((P8 *)_this)->state0 = 3;
#ifdef VAR_RANGES
		logval("WebUser:state0", ((int)((P8 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(22, 21, 22) */
		reached[8][21] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P8 *)_this)->completed[1]);
		((P8 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("WebUser:completed[1]", ((int)((P8 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 17: // STATE 22 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1003 - [internal_queue!3] (0:0:0 - 1)
		IfNotBlocked
		reached[8][22] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P8 *)_this)->internal_queue]&2)
		{	q_S_check(((P8 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P8 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P8 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P8 *)_this)->internal_queue, 0, 3, 0, 1);
		if (q_zero(((P8 *)_this)->internal_queue)) { boq = ((P8 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 18: // STATE 24 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1005 - [(((state0==2)&&(current_event==2)))] (28:0:5 - 1)
		IfNotBlocked
		reached[8][24] = 1;
		if (!(((((int)((P8 *)_this)->state0)==2)&&(((int)((P8 *)_this)->current_event)==2))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0 */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P8 *)_this)->state0;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P8 *)_this)->state0 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P8 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P8 *)_this)->current_event = 0;
		/* merge: state0 = 0(28, 25, 28) */
		reached[8][25] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P8 *)_this)->state0);
		((P8 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("WebUser:state0", ((int)((P8 *)_this)->state0));
#endif
		;
		/* merge: state0 = 4(28, 26, 28) */
		reached[8][26] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P8 *)_this)->state0);
		((P8 *)_this)->state0 = 4;
#ifdef VAR_RANGES
		logval("WebUser:state0", ((int)((P8 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(28, 27, 28) */
		reached[8][27] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P8 *)_this)->completed[1]);
		((P8 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("WebUser:completed[1]", ((int)((P8 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 19: // STATE 28 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1009 - [internal_queue!4] (0:0:0 - 1)
		IfNotBlocked
		reached[8][28] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P8 *)_this)->internal_queue]&2)
		{	q_S_check(((P8 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P8 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P8 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 4); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P8 *)_this)->internal_queue, 0, 4, 0, 1);
		if (q_zero(((P8 *)_this)->internal_queue)) { boq = ((P8 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 20: // STATE 30 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1011 - [((((state0==3)&&(current_event==3))&&(completed[1]==1)))] (39:0:2 - 1)
		IfNotBlocked
		reached[8][30] = 1;
		if (!((((((int)((P8 *)_this)->state0)==3)&&(((int)((P8 *)_this)->current_event)==3))&&(((int)((P8 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P8 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P8 *)_this)->current_event = 0;
		/* merge: state0_transition = 2(0, 31, 39) */
		reached[8][31] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P8 *)_this)->state0_transition);
		((P8 *)_this)->state0_transition = 2;
#ifdef VAR_RANGES
		logval("WebUser:state0_transition", ((int)((P8 *)_this)->state0_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 32, 39) */
		reached[8][32] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 21: // STATE 33 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1014 - [((((state0==4)&&(current_event==4))&&(completed[1]==1)))] (39:0:2 - 1)
		IfNotBlocked
		reached[8][33] = 1;
		if (!((((((int)((P8 *)_this)->state0)==4)&&(((int)((P8 *)_this)->current_event)==4))&&(((int)((P8 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P8 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P8 *)_this)->current_event = 0;
		/* merge: state0_transition = 3(0, 34, 39) */
		reached[8][34] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P8 *)_this)->state0_transition);
		((P8 *)_this)->state0_transition = 3;
#ifdef VAR_RANGES
		logval("WebUser:state0_transition", ((int)((P8 *)_this)->state0_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 35, 39) */
		reached[8][35] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 22: // STATE 40 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1023 - [((state0_transition==2))] (62:0:5 - 1)
		IfNotBlocked
		reached[8][40] = 1;
		if (!((((int)((P8 *)_this)->state0_transition)==2)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P8 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P8 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(62, 41, 62) */
		reached[8][41] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P8 *)_this)->state0_transition);
		((P8 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("WebUser:state0_transition", ((int)((P8 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(62, 42, 62) */
		reached[8][42] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P8 *)_this)->completed[1]);
		((P8 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("WebUser:completed[1]", ((int)((P8 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(62, 43, 62) */
		reached[8][43] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P8 *)_this)->state0);
		((P8 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("WebUser:state0", ((int)((P8 *)_this)->state0));
#endif
		;
		/* merge: state0 = 5(62, 44, 62) */
		reached[8][44] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P8 *)_this)->state0);
		((P8 *)_this)->state0 = 5;
#ifdef VAR_RANGES
		logval("WebUser:state0", ((int)((P8 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 58, 62) */
		reached[8][58] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 23: // STATE 45 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1028 - [((state0_transition==1))] (48:0:3 - 1)
		IfNotBlocked
		reached[8][45] = 1;
		if (!((((int)((P8 *)_this)->state0_transition)==1)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((P8 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P8 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(48, 46, 48) */
		reached[8][46] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P8 *)_this)->state0_transition);
		((P8 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("WebUser:state0_transition", ((int)((P8 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(48, 47, 48) */
		reached[8][47] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P8 *)_this)->state0);
		((P8 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("WebUser:state0", ((int)((P8 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 24: // STATE 48 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1031 - [event_queues[(role-1)]!1,ack_in] (0:0:0 - 1)
		IfNotBlocked
		reached[8][48] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[now.event_queues[ Index((((int)((P8 *)_this)->role)-1), 15) ]]&2)
		{	q_S_check(now.event_queues[ Index((((int)((P8 *)_this)->role)-1), 15) ], II);
		}
#endif
		if (q_full(now.event_queues[ Index((((int)((P8 *)_this)->role)-1), 15) ]))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.event_queues[ Index((((int)((P8 *)_this)->role)-1), 15) ]);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((P8 *)_this)->ack_in); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.event_queues[ Index((((int)((P8 *)_this)->role)-1), 15) ], 0, 1, ((P8 *)_this)->ack_in, 2);
		if (q_zero(now.event_queues[ Index((((int)((P8 *)_this)->role)-1), 15) ])) { boq = now.event_queues[ Index((((int)((P8 *)_this)->role)-1), 15) ]; };
		_m = 2; goto P999; /* 0 */
	case 25: // STATE 49 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1032 - [ack_in?_] (62:0:2 - 1)
		reached[8][49] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P8 *)_this)->ack_in]&1)
		{	q_R_check(((P8 *)_this)->ack_in, II);
		}
#endif
		if (q_zero(((P8 *)_this)->ack_in))
		{	if (boq != ((P8 *)_this)->ack_in) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P8 *)_this)->ack_in) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = qrecv(((P8 *)_this)->ack_in, XX-1, 0, 0);
		;
		qrecv(((P8 *)_this)->ack_in, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P8 *)_this)->ack_in);
			sprintf(simtmp, "%d", ((int)_)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P8 *)_this)->ack_in))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		/* merge: state0 = 2(0, 50, 62) */
		reached[8][50] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P8 *)_this)->state0);
		((P8 *)_this)->state0 = 2;
#ifdef VAR_RANGES
		logval("WebUser:state0", ((int)((P8 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 58, 62) */
		reached[8][58] = 1;
		;
		_m = 4; goto P999; /* 2 */
	case 26: // STATE 51 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1034 - [((state0_transition==3))] (62:0:5 - 1)
		IfNotBlocked
		reached[8][51] = 1;
		if (!((((int)((P8 *)_this)->state0_transition)==3)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P8 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P8 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(62, 52, 62) */
		reached[8][52] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P8 *)_this)->state0_transition);
		((P8 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("WebUser:state0_transition", ((int)((P8 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(62, 53, 62) */
		reached[8][53] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P8 *)_this)->completed[1]);
		((P8 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("WebUser:completed[1]", ((int)((P8 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(62, 54, 62) */
		reached[8][54] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P8 *)_this)->state0);
		((P8 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("WebUser:state0", ((int)((P8 *)_this)->state0));
#endif
		;
		/* merge: state0 = 5(62, 55, 62) */
		reached[8][55] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P8 *)_this)->state0);
		((P8 *)_this)->state0 = 5;
#ifdef VAR_RANGES
		logval("WebUser:state0", ((int)((P8 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 58, 62) */
		reached[8][58] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 27: // STATE 59 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1042 - [((state0_transition!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[8][59] = 1;
		if (!((((int)((P8 *)_this)->state0_transition)!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 28: // STATE 64 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1047 - [((state0!=5))] (11:0:0 - 1)
		IfNotBlocked
		reached[8][64] = 1;
		if (!((((int)((P8 *)_this)->state0)!=5)))
			continue;
		/* merge: goto main(0, 65, 11) */
		reached[8][65] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 29: // STATE 71 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1054 - [(0)] (0:0:0 - 2)
		IfNotBlocked
		reached[8][71] = 1;
		if (!(0))
			continue;
		_m = 3; goto P999; /* 0 */
	case 30: // STATE 72 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:1055 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[8][72] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC CustomerProfile */
	case 31: // STATE 1 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:813 - [cust = initialiser_cust0] (0:131:3 - 1)
		IfNotBlocked
		reached[7][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P7 *)_this)->cust);
		((P7 *)_this)->cust = ((int)((P7 *)_this)->initialiser_cust0);
#ifdef VAR_RANGES
		logval("CustomerProfile:cust", ((int)((P7 *)_this)->cust));
#endif
		;
		/* merge: state0 = 1(131, 2, 131) */
		reached[7][2] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 1;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		/* merge: state0_transition = 1(131, 3, 131) */
		reached[7][3] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->state0_transition);
		((P7 *)_this)->state0_transition = 1;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0_transition", ((int)((P7 *)_this)->state0_transition));
#endif
		;
		/* merge: goto transitionFiring(0, 4, 131) */
		reached[7][4] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 32: // STATE 6 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:819 - [current_event = 0] (0:0:1 - 3)
		IfNotBlocked
		reached[7][6] = 1;
		(trpt+1)->bup.oval = ((int)((P7 *)_this)->current_event);
		((P7 *)_this)->current_event = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:current_event", ((int)((P7 *)_this)->current_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 33: // STATE 7 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:821 - [(internal_queue?[current_event])] (0:0:0 - 1)
		IfNotBlocked
		reached[7][7] = 1;
		if (!(
#ifndef XUSAFE
		(!(q_claim[((P7 *)_this)->internal_queue]&1) || q_R_check(((P7 *)_this)->internal_queue, II)) &&
		(!(q_claim[((P7 *)_this)->internal_queue]&2) || q_S_check(((P7 *)_this)->internal_queue, II)) &&
#endif
		not_RV(((P7 *)_this)->internal_queue) && \
		(q_len(((P7 *)_this)->internal_queue) > 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 34: // STATE 8 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:822 - [internal_queue?current_event] (0:0:1 - 1)
		reached[7][8] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P7 *)_this)->internal_queue]&1)
		{	q_R_check(((P7 *)_this)->internal_queue, II);
		}
#endif
		if (q_zero(((P7 *)_this)->internal_queue))
		{	if (boq != ((P7 *)_this)->internal_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P7 *)_this)->internal_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.oval = ((int)((P7 *)_this)->current_event);
		;
		((P7 *)_this)->current_event = qrecv(((P7 *)_this)->internal_queue, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("CustomerProfile:current_event", ((int)((P7 *)_this)->current_event));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P7 *)_this)->internal_queue);
			sprintf(simtmp, "%d", ((int)((P7 *)_this)->current_event)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P7 *)_this)->internal_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 35: // STATE 10 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:824 - [event_queue?current_event,ack_out] (0:0:2 - 1)
		reached[7][10] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P7 *)_this)->event_queue]&1)
		{	q_R_check(((P7 *)_this)->event_queue, II);
		}
#endif
		if (q_zero(((P7 *)_this)->event_queue))
		{	if (boq != ((P7 *)_this)->event_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P7 *)_this)->event_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P7 *)_this)->current_event);
		(trpt+1)->bup.ovals[1] = ((P7 *)_this)->ack_out;
		;
		((P7 *)_this)->current_event = qrecv(((P7 *)_this)->event_queue, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("CustomerProfile:current_event", ((int)((P7 *)_this)->current_event));
#endif
		;
		((P7 *)_this)->ack_out = qrecv(((P7 *)_this)->event_queue, XX-1, 1, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P7 *)_this)->event_queue);
			sprintf(simtmp, "%d", ((int)((P7 *)_this)->current_event)); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((P7 *)_this)->ack_out); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P7 *)_this)->event_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 36: // STATE 13 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:828 - [(((state0==2)&&(current_event==2)))] (59:0:1 - 1)
		IfNotBlocked
		reached[7][13] = 1;
		if (!(((((int)((P7 *)_this)->state0)==2)&&(((int)((P7 *)_this)->current_event)==2))))
			continue;
		/* merge: state0_transition = 2(0, 14, 59) */
		reached[7][14] = 1;
		(trpt+1)->bup.oval = ((int)((P7 *)_this)->state0_transition);
		((P7 *)_this)->state0_transition = 2;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0_transition", ((int)((P7 *)_this)->state0_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 15, 59) */
		reached[7][15] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 37: // STATE 16 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:831 - [(((state0==2)&&(current_event==1)))] (59:0:1 - 1)
		IfNotBlocked
		reached[7][16] = 1;
		if (!(((((int)((P7 *)_this)->state0)==2)&&(((int)((P7 *)_this)->current_event)==1))))
			continue;
		/* merge: state0_transition = 3(0, 17, 59) */
		reached[7][17] = 1;
		(trpt+1)->bup.oval = ((int)((P7 *)_this)->state0_transition);
		((P7 *)_this)->state0_transition = 3;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0_transition", ((int)((P7 *)_this)->state0_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 18, 59) */
		reached[7][18] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 38: // STATE 22 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:837 - [((state0==3))] (0:0:0 - 1)
		IfNotBlocked
		reached[7][22] = 1;
		if (!((((int)((P7 *)_this)->state0)==3)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 39: // STATE 23 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:839 - [(((((state1==4)&&(current_event==3))&&(completed[2]==1))&&( ((( (((CustomerProfile_primeCustomer==1)==0)) -> (0) : ((CustomerProfile_totalPriceOfItems>=35)) )==0)) -> (0) : ((CustomerProfile_billingAddress>=56072)) )))] (29:0:7 - 1)
		IfNotBlocked
		reached[7][23] = 1;
		if (!(((((((int)((P7 *)_this)->state1)==4)&&(((int)((P7 *)_this)->current_event)==3))&&(((int)((P7 *)_this)->completed[2])==1))&&( ((( (((((int)now.CustomerProfile_primeCustomer)==1)==0)) ? (0) : ((now.CustomerProfile_totalPriceOfItems>=35)) )==0)) ? (0) : ((now.CustomerProfile_billingAddress>=56072)) ))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state1 */  (trpt+1)->bup.ovals = grab_ints(7);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state1;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state1 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P7 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->current_event = 0;
		/* merge: completed[2] = 0(29, 24, 29) */
		reached[7][24] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->completed[2]);
		((P7 *)_this)->completed[2] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[2]", ((int)((P7 *)_this)->completed[2]));
#endif
		;
		/* merge: state1 = 0(29, 25, 29) */
		reached[7][25] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: CustomerProfile_freeDelivery = 1(29, 26, 29) */
		reached[7][26] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.CustomerProfile_freeDelivery);
		now.CustomerProfile_freeDelivery = 1;
#ifdef VAR_RANGES
		logval("CustomerProfile_freeDelivery", ((int)now.CustomerProfile_freeDelivery));
#endif
		;
		/* merge: state1 = 5(29, 27, 29) */
		reached[7][27] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 5;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: completed[2] = 1(29, 28, 29) */
		reached[7][28] = 1;
		(trpt+1)->bup.ovals[6] = ((int)((P7 *)_this)->completed[2]);
		((P7 *)_this)->completed[2] = 1;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[2]", ((int)((P7 *)_this)->completed[2]));
#endif
		;
		_m = 3; goto P999; /* 5 */
	case 40: // STATE 29 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:845 - [internal_queue!4] (0:0:0 - 1)
		IfNotBlocked
		reached[7][29] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P7 *)_this)->internal_queue]&2)
		{	q_S_check(((P7 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P7 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P7 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 4); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P7 *)_this)->internal_queue, 0, 4, 0, 1);
		if (q_zero(((P7 *)_this)->internal_queue)) { boq = ((P7 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 41: // STATE 31 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:847 - [(((((state1==4)&&(current_event==3))&&(completed[2]==1))&&( ((( (((CustomerProfile_primeCustomer!=1)==1)) -> (1) : ((CustomerProfile_totalPriceOfItems<35)) )==1)) -> (1) : ((CustomerProfile_billingAddress<56072)) )))] (38:0:8 - 1)
		IfNotBlocked
		reached[7][31] = 1;
		if (!(((((((int)((P7 *)_this)->state1)==4)&&(((int)((P7 *)_this)->current_event)==3))&&(((int)((P7 *)_this)->completed[2])==1))&&( ((( (((((int)now.CustomerProfile_primeCustomer)!=1)==1)) ? (1) : ((now.CustomerProfile_totalPriceOfItems<35)) )==1)) ? (1) : ((now.CustomerProfile_billingAddress<56072)) ))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state1 */  (trpt+1)->bup.ovals = grab_ints(8);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state1;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state1 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P7 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->current_event = 0;
		/* merge: completed[2] = 0(38, 32, 38) */
		reached[7][32] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->completed[2]);
		((P7 *)_this)->completed[2] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[2]", ((int)((P7 *)_this)->completed[2]));
#endif
		;
		/* merge: state1 = 0(38, 33, 38) */
		reached[7][33] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: CustomerProfile_freeDelivery = 0(38, 34, 38) */
		reached[7][34] = 1;
		(trpt+1)->bup.ovals[4] = ((int)now.CustomerProfile_freeDelivery);
		now.CustomerProfile_freeDelivery = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile_freeDelivery", ((int)now.CustomerProfile_freeDelivery));
#endif
		;
		/* merge: CustomerProfile_totalPriceOfItems = 5(38, 35, 38) */
		reached[7][35] = 1;
		(trpt+1)->bup.ovals[5] = now.CustomerProfile_totalPriceOfItems;
		now.CustomerProfile_totalPriceOfItems = 5;
#ifdef VAR_RANGES
		logval("CustomerProfile_totalPriceOfItems", now.CustomerProfile_totalPriceOfItems);
#endif
		;
		/* merge: state1 = 6(38, 36, 38) */
		reached[7][36] = 1;
		(trpt+1)->bup.ovals[6] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 6;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: completed[2] = 1(38, 37, 38) */
		reached[7][37] = 1;
		(trpt+1)->bup.ovals[7] = ((int)((P7 *)_this)->completed[2]);
		((P7 *)_this)->completed[2] = 1;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[2]", ((int)((P7 *)_this)->completed[2]));
#endif
		;
		_m = 3; goto P999; /* 6 */
	case 42: // STATE 38 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:854 - [internal_queue!5] (0:0:0 - 1)
		IfNotBlocked
		reached[7][38] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P7 *)_this)->internal_queue]&2)
		{	q_S_check(((P7 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P7 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P7 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 5); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P7 *)_this)->internal_queue, 0, 5, 0, 1);
		if (q_zero(((P7 *)_this)->internal_queue)) { boq = ((P7 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 43: // STATE 40 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:856 - [((((state1==5)&&(current_event==4))&&(completed[2]==1)))] (59:0:1 - 1)
		IfNotBlocked
		reached[7][40] = 1;
		if (!((((((int)((P7 *)_this)->state1)==5)&&(((int)((P7 *)_this)->current_event)==4))&&(((int)((P7 *)_this)->completed[2])==1))))
			continue;
		/* merge: state1_transition = 4(0, 41, 59) */
		reached[7][41] = 1;
		(trpt+1)->bup.oval = ((int)((P7 *)_this)->state1_transition);
		((P7 *)_this)->state1_transition = 4;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1_transition", ((int)((P7 *)_this)->state1_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 42, 59) */
		reached[7][42] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 44: // STATE 43 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:859 - [((((state1==6)&&(current_event==5))&&(completed[2]==1)))] (59:0:1 - 1)
		IfNotBlocked
		reached[7][43] = 1;
		if (!((((((int)((P7 *)_this)->state1)==6)&&(((int)((P7 *)_this)->current_event)==5))&&(((int)((P7 *)_this)->completed[2])==1))))
			continue;
		/* merge: state1_transition = 5(0, 44, 59) */
		reached[7][44] = 1;
		(trpt+1)->bup.oval = ((int)((P7 *)_this)->state1_transition);
		((P7 *)_this)->state1_transition = 5;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1_transition", ((int)((P7 *)_this)->state1_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 45, 59) */
		reached[7][45] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 45: // STATE 52 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:867 - [((((state0==3)&&(current_event==6))&&(completed[1]==1)))] (59:0:1 - 1)
		IfNotBlocked
		reached[7][52] = 1;
		if (!((((((int)((P7 *)_this)->state0)==3)&&(((int)((P7 *)_this)->current_event)==6))&&(((int)((P7 *)_this)->completed[1])==1))))
			continue;
		/* merge: state0_transition = 6(0, 53, 59) */
		reached[7][53] = 1;
		(trpt+1)->bup.oval = ((int)((P7 *)_this)->state0_transition);
		((P7 *)_this)->state0_transition = 6;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0_transition", ((int)((P7 *)_this)->state0_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 54, 59) */
		reached[7][54] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 46: // STATE 60 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:877 - [((current_event==2))] (0:0:1 - 1)
		IfNotBlocked
		reached[7][60] = 1;
		if (!((((int)((P7 *)_this)->current_event)==2)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.oval = ((P7 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->current_event = 0;
		_m = 3; goto P999; /* 0 */
	case 47: // STATE 61 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:878 - [ack_out!1] (0:0:0 - 1)
		IfNotBlocked
		reached[7][61] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P7 *)_this)->ack_out]&2)
		{	q_S_check(((P7 *)_this)->ack_out, II);
		}
#endif
		if (q_full(((P7 *)_this)->ack_out))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P7 *)_this)->ack_out);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P7 *)_this)->ack_out, 0, 1, 0, 1);
		if (q_zero(((P7 *)_this)->ack_out)) { boq = ((P7 *)_this)->ack_out; };
		_m = 2; goto P999; /* 0 */
	case 48: // STATE 65 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:883 - [((state0_transition!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[7][65] = 1;
		if (!((((int)((P7 *)_this)->state0_transition)!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 49: // STATE 66 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:885 - [((state0_transition==2))] (136:0:7 - 1)
		IfNotBlocked
		reached[7][66] = 1;
		if (!((((int)((P7 *)_this)->state0_transition)==2)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(7);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(136, 67, 136) */
		reached[7][67] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->state0_transition);
		((P7 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0_transition", ((int)((P7 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(136, 68, 136) */
		reached[7][68] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		/* merge: CustomerProfile_freeDelivery = 0(136, 69, 136) */
		reached[7][69] = 1;
		(trpt+1)->bup.ovals[3] = ((int)now.CustomerProfile_freeDelivery);
		now.CustomerProfile_freeDelivery = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile_freeDelivery", ((int)now.CustomerProfile_freeDelivery));
#endif
		;
		/* merge: state0 = 3(136, 70, 136) */
		reached[7][70] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 3;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		/* merge: state1 = 7(136, 71, 136) */
		reached[7][71] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 7;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: state1_transition = 7(136, 72, 136) */
		reached[7][72] = 1;
		(trpt+1)->bup.ovals[6] = ((int)((P7 *)_this)->state1_transition);
		((P7 *)_this)->state1_transition = 7;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1_transition", ((int)((P7 *)_this)->state1_transition));
#endif
		;
		/* merge: .(goto)(0, 102, 136) */
		reached[7][102] = 1;
		;
		/* merge: .(goto)(0, 132, 136) */
		reached[7][132] = 1;
		;
		_m = 3; goto P999; /* 8 */
	case 50: // STATE 73 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:892 - [((state0_transition==6))] (86:0:2 - 1)
		IfNotBlocked
		reached[7][73] = 1;
		if (!((((int)((P7 *)_this)->state0_transition)==6)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(0, 74, 86) */
		reached[7][74] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->state0_transition);
		((P7 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0_transition", ((int)((P7 *)_this)->state0_transition));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 51: // STATE 75 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:895 - [((state1==4))] (90:0:5 - 1)
		IfNotBlocked
		reached[7][75] = 1;
		if (!((((int)((P7 *)_this)->state1)==4)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state1 */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state1;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state1 = 0;
		/* merge: completed[2] = 0(90, 76, 90) */
		reached[7][76] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->completed[2]);
		((P7 *)_this)->completed[2] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[2]", ((int)((P7 *)_this)->completed[2]));
#endif
		;
		/* merge: state1 = 0(90, 77, 90) */
		reached[7][77] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: .(goto)(90, 87, 90) */
		reached[7][87] = 1;
		;
		/* merge: completed[1] = 0(90, 88, 90) */
		reached[7][88] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P7 *)_this)->completed[1]);
		((P7 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[1]", ((int)((P7 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(90, 89, 90) */
		reached[7][89] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 5 */
	case 52: // STATE 78 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:898 - [((state1==5))] (90:0:5 - 1)
		IfNotBlocked
		reached[7][78] = 1;
		if (!((((int)((P7 *)_this)->state1)==5)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state1 */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state1;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state1 = 0;
		/* merge: completed[2] = 0(90, 79, 90) */
		reached[7][79] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->completed[2]);
		((P7 *)_this)->completed[2] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[2]", ((int)((P7 *)_this)->completed[2]));
#endif
		;
		/* merge: state1 = 0(90, 80, 90) */
		reached[7][80] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: .(goto)(90, 87, 90) */
		reached[7][87] = 1;
		;
		/* merge: completed[1] = 0(90, 88, 90) */
		reached[7][88] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P7 *)_this)->completed[1]);
		((P7 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[1]", ((int)((P7 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(90, 89, 90) */
		reached[7][89] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 5 */
	case 53: // STATE 81 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:901 - [((state1==8))] (90:0:4 - 1)
		IfNotBlocked
		reached[7][81] = 1;
		if (!((((int)((P7 *)_this)->state1)==8)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state1 */  (trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state1;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state1 = 0;
		/* merge: state1 = 0(90, 82, 90) */
		reached[7][82] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: .(goto)(90, 87, 90) */
		reached[7][87] = 1;
		;
		/* merge: completed[1] = 0(90, 88, 90) */
		reached[7][88] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->completed[1]);
		((P7 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[1]", ((int)((P7 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(90, 89, 90) */
		reached[7][89] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 54: // STATE 83 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:903 - [((state1==6))] (90:0:5 - 1)
		IfNotBlocked
		reached[7][83] = 1;
		if (!((((int)((P7 *)_this)->state1)==6)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state1 */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state1;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state1 = 0;
		/* merge: completed[2] = 0(90, 84, 90) */
		reached[7][84] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->completed[2]);
		((P7 *)_this)->completed[2] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[2]", ((int)((P7 *)_this)->completed[2]));
#endif
		;
		/* merge: state1 = 0(90, 85, 90) */
		reached[7][85] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: .(goto)(90, 87, 90) */
		reached[7][87] = 1;
		;
		/* merge: completed[1] = 0(90, 88, 90) */
		reached[7][88] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P7 *)_this)->completed[1]);
		((P7 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[1]", ((int)((P7 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(90, 89, 90) */
		reached[7][89] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 5 */
	case 55: // STATE 88 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:907 - [completed[1] = 0] (0:90:2 - 5)
		IfNotBlocked
		reached[7][88] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P7 *)_this)->completed[1]);
		((P7 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[1]", ((int)((P7 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(90, 89, 90) */
		reached[7][89] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 56: // STATE 90 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:909 - [event_queues[(cust-1)]!1,ack_in] (0:0:0 - 1)
		IfNotBlocked
		reached[7][90] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[now.event_queues[ Index((((int)((P7 *)_this)->cust)-1), 15) ]]&2)
		{	q_S_check(now.event_queues[ Index((((int)((P7 *)_this)->cust)-1), 15) ], II);
		}
#endif
		if (q_full(now.event_queues[ Index((((int)((P7 *)_this)->cust)-1), 15) ]))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.event_queues[ Index((((int)((P7 *)_this)->cust)-1), 15) ]);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((P7 *)_this)->ack_in); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.event_queues[ Index((((int)((P7 *)_this)->cust)-1), 15) ], 0, 1, ((P7 *)_this)->ack_in, 2);
		if (q_zero(now.event_queues[ Index((((int)((P7 *)_this)->cust)-1), 15) ])) { boq = now.event_queues[ Index((((int)((P7 *)_this)->cust)-1), 15) ]; };
		_m = 2; goto P999; /* 0 */
	case 57: // STATE 91 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:910 - [state0 = 2] (0:0:1 - 1)
		IfNotBlocked
		reached[7][91] = 1;
		(trpt+1)->bup.oval = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 2;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 58: // STATE 92 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:911 - [((state0_transition==3))] (136:0:4 - 1)
		IfNotBlocked
		reached[7][92] = 1;
		if (!((((int)((P7 *)_this)->state0_transition)==3)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(136, 93, 136) */
		reached[7][93] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->state0_transition);
		((P7 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0_transition", ((int)((P7 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(136, 94, 136) */
		reached[7][94] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		/* merge: state0 = 9(136, 95, 136) */
		reached[7][95] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 9;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 102, 136) */
		reached[7][102] = 1;
		;
		/* merge: .(goto)(0, 132, 136) */
		reached[7][132] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 59: // STATE 96 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:915 - [((state0_transition==1))] (136:0:4 - 1)
		IfNotBlocked
		reached[7][96] = 1;
		if (!((((int)((P7 *)_this)->state0_transition)==1)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(136, 97, 136) */
		reached[7][97] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->state0_transition);
		((P7 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0_transition", ((int)((P7 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(136, 98, 136) */
		reached[7][98] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		/* merge: state0 = 2(136, 99, 136) */
		reached[7][99] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P7 *)_this)->state0);
		((P7 *)_this)->state0 = 2;
#ifdef VAR_RANGES
		logval("CustomerProfile:state0", ((int)((P7 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 102, 136) */
		reached[7][102] = 1;
		;
		/* merge: .(goto)(0, 132, 136) */
		reached[7][132] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 60: // STATE 104 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:923 - [((state1_transition!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[7][104] = 1;
		if (!((((int)((P7 *)_this)->state1_transition)!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 61: // STATE 105 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:925 - [((state1_transition==4))] (111:0:6 - 1)
		IfNotBlocked
		reached[7][105] = 1;
		if (!((((int)((P7 *)_this)->state1_transition)==4)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state1_transition */  (trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state1_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state1_transition = 0;
		/* merge: state1_transition = 0(111, 106, 111) */
		reached[7][106] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->state1_transition);
		((P7 *)_this)->state1_transition = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1_transition", ((int)((P7 *)_this)->state1_transition));
#endif
		;
		/* merge: completed[2] = 0(111, 107, 111) */
		reached[7][107] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->completed[2]);
		((P7 *)_this)->completed[2] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[2]", ((int)((P7 *)_this)->completed[2]));
#endif
		;
		/* merge: state1 = 0(111, 108, 111) */
		reached[7][108] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: state1 = 8(111, 109, 111) */
		reached[7][109] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 8;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: completed[1] = 1(111, 110, 111) */
		reached[7][110] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P7 *)_this)->completed[1]);
		((P7 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[1]", ((int)((P7 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 5 */
	case 62: // STATE 111 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:931 - [internal_queue!6] (0:0:0 - 1)
		IfNotBlocked
		reached[7][111] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P7 *)_this)->internal_queue]&2)
		{	q_S_check(((P7 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P7 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P7 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 6); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P7 *)_this)->internal_queue, 0, 6, 0, 1);
		if (q_zero(((P7 *)_this)->internal_queue)) { boq = ((P7 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 63: // STATE 112 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:932 - [((state1_transition==5))] (118:0:6 - 1)
		IfNotBlocked
		reached[7][112] = 1;
		if (!((((int)((P7 *)_this)->state1_transition)==5)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state1_transition */  (trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state1_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state1_transition = 0;
		/* merge: state1_transition = 0(118, 113, 118) */
		reached[7][113] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->state1_transition);
		((P7 *)_this)->state1_transition = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1_transition", ((int)((P7 *)_this)->state1_transition));
#endif
		;
		/* merge: completed[2] = 0(118, 114, 118) */
		reached[7][114] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->completed[2]);
		((P7 *)_this)->completed[2] = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[2]", ((int)((P7 *)_this)->completed[2]));
#endif
		;
		/* merge: state1 = 0(118, 115, 118) */
		reached[7][115] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: state1 = 8(118, 116, 118) */
		reached[7][116] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 8;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: completed[1] = 1(118, 117, 118) */
		reached[7][117] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P7 *)_this)->completed[1]);
		((P7 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[1]", ((int)((P7 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 5 */
	case 64: // STATE 118 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:938 - [internal_queue!6] (0:0:0 - 1)
		IfNotBlocked
		reached[7][118] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P7 *)_this)->internal_queue]&2)
		{	q_S_check(((P7 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P7 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P7 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 6); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P7 *)_this)->internal_queue, 0, 6, 0, 1);
		if (q_zero(((P7 *)_this)->internal_queue)) { boq = ((P7 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 65: // STATE 119 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:939 - [((state1_transition==7))] (124:0:5 - 1)
		IfNotBlocked
		reached[7][119] = 1;
		if (!((((int)((P7 *)_this)->state1_transition)==7)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state1_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P7 *)_this)->state1_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P7 *)_this)->state1_transition = 0;
		/* merge: state1_transition = 0(124, 120, 124) */
		reached[7][120] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P7 *)_this)->state1_transition);
		((P7 *)_this)->state1_transition = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1_transition", ((int)((P7 *)_this)->state1_transition));
#endif
		;
		/* merge: state1 = 0(124, 121, 124) */
		reached[7][121] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 0;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: state1 = 4(124, 122, 124) */
		reached[7][122] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P7 *)_this)->state1);
		((P7 *)_this)->state1 = 4;
#ifdef VAR_RANGES
		logval("CustomerProfile:state1", ((int)((P7 *)_this)->state1));
#endif
		;
		/* merge: completed[2] = 1(124, 123, 124) */
		reached[7][123] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P7 *)_this)->completed[2]);
		((P7 *)_this)->completed[2] = 1;
#ifdef VAR_RANGES
		logval("CustomerProfile:completed[2]", ((int)((P7 *)_this)->completed[2]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 66: // STATE 124 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:944 - [internal_queue!3] (0:0:0 - 1)
		IfNotBlocked
		reached[7][124] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P7 *)_this)->internal_queue]&2)
		{	q_S_check(((P7 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P7 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P7 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P7 *)_this)->internal_queue, 0, 3, 0, 1);
		if (q_zero(((P7 *)_this)->internal_queue)) { boq = ((P7 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 67: // STATE 133 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:951 - [(((state0_transition!=0)||(state1_transition!=0)))] (0:0:0 - 1)
		IfNotBlocked
		reached[7][133] = 1;
		if (!(((((int)((P7 *)_this)->state0_transition)!=0)||(((int)((P7 *)_this)->state1_transition)!=0))))
			continue;
		_m = 3; goto P999; /* 0 */
	case 68: // STATE 138 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:956 - [((state0!=9))] (6:0:0 - 1)
		IfNotBlocked
		reached[7][138] = 1;
		if (!((((int)((P7 *)_this)->state0)!=9)))
			continue;
		/* merge: goto main(0, 139, 6) */
		reached[7][139] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 69: // STATE 145 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:963 - [(0)] (0:0:0 - 2)
		IfNotBlocked
		reached[7][145] = 1;
		if (!(0))
			continue;
		_m = 3; goto P999; /* 0 */
	case 70: // STATE 146 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:964 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[7][146] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC LineItem */
	case 71: // STATE 1 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:739 - [state0 = 1] (0:38:2 - 1)
		IfNotBlocked
		reached[6][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P6 *)_this)->state0);
		((P6 *)_this)->state0 = 1;
#ifdef VAR_RANGES
		logval("LineItem:state0", ((int)((P6 *)_this)->state0));
#endif
		;
		/* merge: state0_transition = 1(38, 2, 38) */
		reached[6][2] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P6 *)_this)->state0_transition);
		((P6 *)_this)->state0_transition = 1;
#ifdef VAR_RANGES
		logval("LineItem:state0_transition", ((int)((P6 *)_this)->state0_transition));
#endif
		;
		/* merge: goto transitionFiring(0, 3, 38) */
		reached[6][3] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 72: // STATE 5 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:744 - [current_event = 0] (0:0:1 - 2)
		IfNotBlocked
		reached[6][5] = 1;
		(trpt+1)->bup.oval = ((int)((P6 *)_this)->current_event);
		((P6 *)_this)->current_event = 0;
#ifdef VAR_RANGES
		logval("LineItem:current_event", ((int)((P6 *)_this)->current_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 73: // STATE 6 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:746 - [(internal_queue?[current_event])] (0:0:0 - 1)
		IfNotBlocked
		reached[6][6] = 1;
		if (!(
#ifndef XUSAFE
		(!(q_claim[((P6 *)_this)->internal_queue]&1) || q_R_check(((P6 *)_this)->internal_queue, II)) &&
		(!(q_claim[((P6 *)_this)->internal_queue]&2) || q_S_check(((P6 *)_this)->internal_queue, II)) &&
#endif
		not_RV(((P6 *)_this)->internal_queue) && \
		(q_len(((P6 *)_this)->internal_queue) > 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 74: // STATE 7 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:747 - [internal_queue?current_event] (0:0:1 - 1)
		reached[6][7] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P6 *)_this)->internal_queue]&1)
		{	q_R_check(((P6 *)_this)->internal_queue, II);
		}
#endif
		if (q_zero(((P6 *)_this)->internal_queue))
		{	if (boq != ((P6 *)_this)->internal_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P6 *)_this)->internal_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.oval = ((int)((P6 *)_this)->current_event);
		;
		((P6 *)_this)->current_event = qrecv(((P6 *)_this)->internal_queue, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("LineItem:current_event", ((int)((P6 *)_this)->current_event));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P6 *)_this)->internal_queue);
			sprintf(simtmp, "%d", ((int)((P6 *)_this)->current_event)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P6 *)_this)->internal_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 75: // STATE 9 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:749 - [event_queue?current_event,ack_out] (0:0:2 - 1)
		reached[6][9] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P6 *)_this)->event_queue]&1)
		{	q_R_check(((P6 *)_this)->event_queue, II);
		}
#endif
		if (q_zero(((P6 *)_this)->event_queue))
		{	if (boq != ((P6 *)_this)->event_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P6 *)_this)->event_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P6 *)_this)->current_event);
		(trpt+1)->bup.ovals[1] = ((P6 *)_this)->ack_out;
		;
		((P6 *)_this)->current_event = qrecv(((P6 *)_this)->event_queue, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("LineItem:current_event", ((int)((P6 *)_this)->current_event));
#endif
		;
		((P6 *)_this)->ack_out = qrecv(((P6 *)_this)->event_queue, XX-1, 1, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P6 *)_this)->event_queue);
			sprintf(simtmp, "%d", ((int)((P6 *)_this)->current_event)); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((P6 *)_this)->ack_out); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P6 *)_this)->event_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 76: // STATE 12 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:753 - [((((state0==2)&&(current_event==1))&&(completed[1]==1)))] (17:0:6 - 1)
		IfNotBlocked
		reached[6][12] = 1;
		if (!((((((int)((P6 *)_this)->state0)==2)&&(((int)((P6 *)_this)->current_event)==1))&&(((int)((P6 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0 */  (trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P6 *)_this)->state0;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P6 *)_this)->state0 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P6 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P6 *)_this)->current_event = 0;
		/* merge: completed[1] = 0(17, 13, 17) */
		reached[6][13] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P6 *)_this)->completed[1]);
		((P6 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("LineItem:completed[1]", ((int)((P6 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(17, 14, 17) */
		reached[6][14] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P6 *)_this)->state0);
		((P6 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("LineItem:state0", ((int)((P6 *)_this)->state0));
#endif
		;
		/* merge: state0 = 3(17, 15, 17) */
		reached[6][15] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P6 *)_this)->state0);
		((P6 *)_this)->state0 = 3;
#ifdef VAR_RANGES
		logval("LineItem:state0", ((int)((P6 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(17, 16, 17) */
		reached[6][16] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P6 *)_this)->completed[1]);
		((P6 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("LineItem:completed[1]", ((int)((P6 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 77: // STATE 17 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:758 - [internal_queue!2] (0:0:0 - 1)
		IfNotBlocked
		reached[6][17] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P6 *)_this)->internal_queue]&2)
		{	q_S_check(((P6 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P6 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P6 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P6 *)_this)->internal_queue, 0, 2, 0, 1);
		if (q_zero(((P6 *)_this)->internal_queue)) { boq = ((P6 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 78: // STATE 19 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:760 - [((((state0==3)&&(current_event==2))&&(completed[1]==1)))] (25:0:2 - 1)
		IfNotBlocked
		reached[6][19] = 1;
		if (!((((((int)((P6 *)_this)->state0)==3)&&(((int)((P6 *)_this)->current_event)==2))&&(((int)((P6 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P6 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P6 *)_this)->current_event = 0;
		/* merge: state0_transition = 2(0, 20, 25) */
		reached[6][20] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P6 *)_this)->state0_transition);
		((P6 *)_this)->state0_transition = 2;
#ifdef VAR_RANGES
		logval("LineItem:state0_transition", ((int)((P6 *)_this)->state0_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 21, 25) */
		reached[6][21] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 79: // STATE 26 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:769 - [((state0_transition==1))] (31:0:5 - 1)
		IfNotBlocked
		reached[6][26] = 1;
		if (!((((int)((P6 *)_this)->state0_transition)==1)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P6 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P6 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(31, 27, 31) */
		reached[6][27] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P6 *)_this)->state0_transition);
		((P6 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("LineItem:state0_transition", ((int)((P6 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(31, 28, 31) */
		reached[6][28] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P6 *)_this)->state0);
		((P6 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("LineItem:state0", ((int)((P6 *)_this)->state0));
#endif
		;
		/* merge: state0 = 2(31, 29, 31) */
		reached[6][29] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P6 *)_this)->state0);
		((P6 *)_this)->state0 = 2;
#ifdef VAR_RANGES
		logval("LineItem:state0", ((int)((P6 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(31, 30, 31) */
		reached[6][30] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P6 *)_this)->completed[1]);
		((P6 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("LineItem:completed[1]", ((int)((P6 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 80: // STATE 31 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:774 - [internal_queue!1] (0:0:0 - 1)
		IfNotBlocked
		reached[6][31] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P6 *)_this)->internal_queue]&2)
		{	q_S_check(((P6 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P6 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P6 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P6 *)_this)->internal_queue, 0, 1, 0, 1);
		if (q_zero(((P6 *)_this)->internal_queue)) { boq = ((P6 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 81: // STATE 32 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:775 - [((state0_transition==2))] (43:0:5 - 1)
		IfNotBlocked
		reached[6][32] = 1;
		if (!((((int)((P6 *)_this)->state0_transition)==2)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P6 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P6 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(43, 33, 43) */
		reached[6][33] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P6 *)_this)->state0_transition);
		((P6 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("LineItem:state0_transition", ((int)((P6 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(43, 34, 43) */
		reached[6][34] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P6 *)_this)->completed[1]);
		((P6 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("LineItem:completed[1]", ((int)((P6 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(43, 35, 43) */
		reached[6][35] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P6 *)_this)->state0);
		((P6 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("LineItem:state0", ((int)((P6 *)_this)->state0));
#endif
		;
		/* merge: state0 = 4(43, 36, 43) */
		reached[6][36] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P6 *)_this)->state0);
		((P6 *)_this)->state0 = 4;
#ifdef VAR_RANGES
		logval("LineItem:state0", ((int)((P6 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 39, 43) */
		reached[6][39] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 82: // STATE 40 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:783 - [((state0_transition!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[6][40] = 1;
		if (!((((int)((P6 *)_this)->state0_transition)!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 83: // STATE 45 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:788 - [((state0!=4))] (5:0:0 - 1)
		IfNotBlocked
		reached[6][45] = 1;
		if (!((((int)((P6 *)_this)->state0)!=4)))
			continue;
		/* merge: goto main(0, 46, 5) */
		reached[6][46] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 84: // STATE 52 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:795 - [(0)] (0:0:0 - 2)
		IfNotBlocked
		reached[6][52] = 1;
		if (!(0))
			continue;
		_m = 3; goto P999; /* 0 */
	case 85: // STATE 53 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:796 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[6][53] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Product */
	case 86: // STATE 1 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:669 - [state0 = 1] (0:38:2 - 1)
		IfNotBlocked
		reached[5][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P5 *)_this)->state0);
		((P5 *)_this)->state0 = 1;
#ifdef VAR_RANGES
		logval("Product:state0", ((int)((P5 *)_this)->state0));
#endif
		;
		/* merge: state0_transition = 1(38, 2, 38) */
		reached[5][2] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P5 *)_this)->state0_transition);
		((P5 *)_this)->state0_transition = 1;
#ifdef VAR_RANGES
		logval("Product:state0_transition", ((int)((P5 *)_this)->state0_transition));
#endif
		;
		/* merge: goto transitionFiring(0, 3, 38) */
		reached[5][3] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 87: // STATE 5 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:674 - [current_event = 0] (0:0:1 - 2)
		IfNotBlocked
		reached[5][5] = 1;
		(trpt+1)->bup.oval = ((int)((P5 *)_this)->current_event);
		((P5 *)_this)->current_event = 0;
#ifdef VAR_RANGES
		logval("Product:current_event", ((int)((P5 *)_this)->current_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 88: // STATE 6 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:676 - [(internal_queue?[current_event])] (0:0:0 - 1)
		IfNotBlocked
		reached[5][6] = 1;
		if (!(
#ifndef XUSAFE
		(!(q_claim[((P5 *)_this)->internal_queue]&1) || q_R_check(((P5 *)_this)->internal_queue, II)) &&
		(!(q_claim[((P5 *)_this)->internal_queue]&2) || q_S_check(((P5 *)_this)->internal_queue, II)) &&
#endif
		not_RV(((P5 *)_this)->internal_queue) && \
		(q_len(((P5 *)_this)->internal_queue) > 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 89: // STATE 7 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:677 - [internal_queue?current_event] (0:0:1 - 1)
		reached[5][7] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P5 *)_this)->internal_queue]&1)
		{	q_R_check(((P5 *)_this)->internal_queue, II);
		}
#endif
		if (q_zero(((P5 *)_this)->internal_queue))
		{	if (boq != ((P5 *)_this)->internal_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P5 *)_this)->internal_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.oval = ((int)((P5 *)_this)->current_event);
		;
		((P5 *)_this)->current_event = qrecv(((P5 *)_this)->internal_queue, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("Product:current_event", ((int)((P5 *)_this)->current_event));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P5 *)_this)->internal_queue);
			sprintf(simtmp, "%d", ((int)((P5 *)_this)->current_event)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P5 *)_this)->internal_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 90: // STATE 9 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:679 - [event_queue?current_event,ack_out] (0:0:2 - 1)
		reached[5][9] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P5 *)_this)->event_queue]&1)
		{	q_R_check(((P5 *)_this)->event_queue, II);
		}
#endif
		if (q_zero(((P5 *)_this)->event_queue))
		{	if (boq != ((P5 *)_this)->event_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P5 *)_this)->event_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P5 *)_this)->current_event);
		(trpt+1)->bup.ovals[1] = ((P5 *)_this)->ack_out;
		;
		((P5 *)_this)->current_event = qrecv(((P5 *)_this)->event_queue, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("Product:current_event", ((int)((P5 *)_this)->current_event));
#endif
		;
		((P5 *)_this)->ack_out = qrecv(((P5 *)_this)->event_queue, XX-1, 1, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P5 *)_this)->event_queue);
			sprintf(simtmp, "%d", ((int)((P5 *)_this)->current_event)); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((P5 *)_this)->ack_out); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P5 *)_this)->event_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 91: // STATE 12 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:683 - [((((state0==2)&&(current_event==1))&&(completed[1]==1)))] (17:0:6 - 1)
		IfNotBlocked
		reached[5][12] = 1;
		if (!((((((int)((P5 *)_this)->state0)==2)&&(((int)((P5 *)_this)->current_event)==1))&&(((int)((P5 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0 */  (trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P5 *)_this)->state0;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P5 *)_this)->state0 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P5 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P5 *)_this)->current_event = 0;
		/* merge: completed[1] = 0(17, 13, 17) */
		reached[5][13] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P5 *)_this)->completed[1]);
		((P5 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Product:completed[1]", ((int)((P5 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(17, 14, 17) */
		reached[5][14] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P5 *)_this)->state0);
		((P5 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Product:state0", ((int)((P5 *)_this)->state0));
#endif
		;
		/* merge: state0 = 3(17, 15, 17) */
		reached[5][15] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P5 *)_this)->state0);
		((P5 *)_this)->state0 = 3;
#ifdef VAR_RANGES
		logval("Product:state0", ((int)((P5 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(17, 16, 17) */
		reached[5][16] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P5 *)_this)->completed[1]);
		((P5 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Product:completed[1]", ((int)((P5 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 92: // STATE 17 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:688 - [internal_queue!2] (0:0:0 - 1)
		IfNotBlocked
		reached[5][17] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P5 *)_this)->internal_queue]&2)
		{	q_S_check(((P5 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P5 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P5 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P5 *)_this)->internal_queue, 0, 2, 0, 1);
		if (q_zero(((P5 *)_this)->internal_queue)) { boq = ((P5 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 93: // STATE 19 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:690 - [((((state0==3)&&(current_event==2))&&(completed[1]==1)))] (25:0:2 - 1)
		IfNotBlocked
		reached[5][19] = 1;
		if (!((((((int)((P5 *)_this)->state0)==3)&&(((int)((P5 *)_this)->current_event)==2))&&(((int)((P5 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P5 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P5 *)_this)->current_event = 0;
		/* merge: state0_transition = 2(0, 20, 25) */
		reached[5][20] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P5 *)_this)->state0_transition);
		((P5 *)_this)->state0_transition = 2;
#ifdef VAR_RANGES
		logval("Product:state0_transition", ((int)((P5 *)_this)->state0_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 21, 25) */
		reached[5][21] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 94: // STATE 26 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:699 - [((state0_transition==2))] (43:0:5 - 1)
		IfNotBlocked
		reached[5][26] = 1;
		if (!((((int)((P5 *)_this)->state0_transition)==2)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P5 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P5 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(43, 27, 43) */
		reached[5][27] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P5 *)_this)->state0_transition);
		((P5 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Product:state0_transition", ((int)((P5 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(43, 28, 43) */
		reached[5][28] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P5 *)_this)->completed[1]);
		((P5 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Product:completed[1]", ((int)((P5 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(43, 29, 43) */
		reached[5][29] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P5 *)_this)->state0);
		((P5 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Product:state0", ((int)((P5 *)_this)->state0));
#endif
		;
		/* merge: state0 = 4(43, 30, 43) */
		reached[5][30] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P5 *)_this)->state0);
		((P5 *)_this)->state0 = 4;
#ifdef VAR_RANGES
		logval("Product:state0", ((int)((P5 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 39, 43) */
		reached[5][39] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 95: // STATE 31 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:704 - [((state0_transition==1))] (36:0:5 - 1)
		IfNotBlocked
		reached[5][31] = 1;
		if (!((((int)((P5 *)_this)->state0_transition)==1)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P5 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P5 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(36, 32, 36) */
		reached[5][32] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P5 *)_this)->state0_transition);
		((P5 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Product:state0_transition", ((int)((P5 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(36, 33, 36) */
		reached[5][33] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P5 *)_this)->state0);
		((P5 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Product:state0", ((int)((P5 *)_this)->state0));
#endif
		;
		/* merge: state0 = 2(36, 34, 36) */
		reached[5][34] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P5 *)_this)->state0);
		((P5 *)_this)->state0 = 2;
#ifdef VAR_RANGES
		logval("Product:state0", ((int)((P5 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(36, 35, 36) */
		reached[5][35] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P5 *)_this)->completed[1]);
		((P5 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Product:completed[1]", ((int)((P5 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 96: // STATE 36 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:709 - [internal_queue!1] (0:0:0 - 1)
		IfNotBlocked
		reached[5][36] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P5 *)_this)->internal_queue]&2)
		{	q_S_check(((P5 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P5 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P5 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P5 *)_this)->internal_queue, 0, 1, 0, 1);
		if (q_zero(((P5 *)_this)->internal_queue)) { boq = ((P5 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 97: // STATE 40 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:713 - [((state0_transition!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[5][40] = 1;
		if (!((((int)((P5 *)_this)->state0_transition)!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 98: // STATE 45 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:718 - [((state0!=4))] (5:0:0 - 1)
		IfNotBlocked
		reached[5][45] = 1;
		if (!((((int)((P5 *)_this)->state0)!=4)))
			continue;
		/* merge: goto main(0, 46, 5) */
		reached[5][46] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 99: // STATE 52 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:725 - [(0)] (0:0:0 - 2)
		IfNotBlocked
		reached[5][52] = 1;
		if (!(0))
			continue;
		_m = 3; goto P999; /* 0 */
	case 100: // STATE 53 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:726 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[5][53] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Customer */
	case 101: // STATE 1 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:572 - [custProf = initialiser_custProf0] (0:64:5 - 1)
		IfNotBlocked
		reached[4][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((int)((P4 *)_this)->custProf);
		((P4 *)_this)->custProf = ((int)((P4 *)_this)->initialiser_custProf0);
#ifdef VAR_RANGES
		logval("Customer:custProf", ((int)((P4 *)_this)->custProf));
#endif
		;
		/* merge: state0 = 1(64, 2, 64) */
		reached[4][2] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P4 *)_this)->state0);
		((P4 *)_this)->state0 = 1;
#ifdef VAR_RANGES
		logval("Customer:state0", ((int)((P4 *)_this)->state0));
#endif
		;
		/* merge: state0_transition = 1(64, 3, 64) */
		reached[4][3] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P4 *)_this)->state0_transition);
		((P4 *)_this)->state0_transition = 1;
#ifdef VAR_RANGES
		logval("Customer:state0_transition", ((int)((P4 *)_this)->state0_transition));
#endif
		;
		/* merge: ChoiceEntry_chosen = 1(64, 4, 64) */
		reached[4][4] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P4 *)_this)->ChoiceEntry_chosen);
		((P4 *)_this)->ChoiceEntry_chosen = 1;
#ifdef VAR_RANGES
		logval("Customer:ChoiceEntry_chosen", ((int)((P4 *)_this)->ChoiceEntry_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: ChoiceEntry_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->ChoiceEntry_chosen = 0;
		/* merge: goto transitionFiring(0, 5, 64) */
		reached[4][5] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 102: // STATE 7 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:579 - [current_event = 0] (0:0:1 - 1)
		IfNotBlocked
		reached[4][7] = 1;
		(trpt+1)->bup.oval = ((int)((P4 *)_this)->current_event);
		((P4 *)_this)->current_event = 0;
#ifdef VAR_RANGES
		logval("Customer:current_event", ((int)((P4 *)_this)->current_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 103: // STATE 8 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:581 - [(internal_queue?[current_event])] (0:0:0 - 1)
		IfNotBlocked
		reached[4][8] = 1;
		if (!(
#ifndef XUSAFE
		(!(q_claim[((P4 *)_this)->internal_queue]&1) || q_R_check(((P4 *)_this)->internal_queue, II)) &&
		(!(q_claim[((P4 *)_this)->internal_queue]&2) || q_S_check(((P4 *)_this)->internal_queue, II)) &&
#endif
		not_RV(((P4 *)_this)->internal_queue) && \
		(q_len(((P4 *)_this)->internal_queue) > 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 104: // STATE 9 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:582 - [internal_queue?current_event] (0:0:1 - 1)
		reached[4][9] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P4 *)_this)->internal_queue]&1)
		{	q_R_check(((P4 *)_this)->internal_queue, II);
		}
#endif
		if (q_zero(((P4 *)_this)->internal_queue))
		{	if (boq != ((P4 *)_this)->internal_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P4 *)_this)->internal_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.oval = ((int)((P4 *)_this)->current_event);
		;
		((P4 *)_this)->current_event = qrecv(((P4 *)_this)->internal_queue, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("Customer:current_event", ((int)((P4 *)_this)->current_event));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P4 *)_this)->internal_queue);
			sprintf(simtmp, "%d", ((int)((P4 *)_this)->current_event)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P4 *)_this)->internal_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 105: // STATE 11 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:584 - [event_queue?current_event,ack_out] (0:0:2 - 1)
		reached[4][11] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P4 *)_this)->event_queue]&1)
		{	q_R_check(((P4 *)_this)->event_queue, II);
		}
#endif
		if (q_zero(((P4 *)_this)->event_queue))
		{	if (boq != ((P4 *)_this)->event_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P4 *)_this)->event_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P4 *)_this)->current_event);
		(trpt+1)->bup.ovals[1] = ((P4 *)_this)->ack_out;
		;
		((P4 *)_this)->current_event = qrecv(((P4 *)_this)->event_queue, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("Customer:current_event", ((int)((P4 *)_this)->current_event));
#endif
		;
		((P4 *)_this)->ack_out = qrecv(((P4 *)_this)->event_queue, XX-1, 1, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P4 *)_this)->event_queue);
			sprintf(simtmp, "%d", ((int)((P4 *)_this)->current_event)); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((P4 *)_this)->ack_out); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P4 *)_this)->event_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 106: // STATE 14 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:588 - [((((state0==2)&&(current_event==2))&&(completed[1]==1)))] (25:0:4 - 1)
		IfNotBlocked
		reached[4][14] = 1;
		if (!((((((int)((P4 *)_this)->state0)==2)&&(((int)((P4 *)_this)->current_event)==2))&&(((int)((P4 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P4 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->current_event = 0;
		/* merge: state0_transition = 2(25, 15, 25) */
		reached[4][15] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P4 *)_this)->state0_transition);
		((P4 *)_this)->state0_transition = 2;
#ifdef VAR_RANGES
		logval("Customer:state0_transition", ((int)((P4 *)_this)->state0_transition));
#endif
		;
		/* merge: ChoiceEntry_chosen = 1(25, 16, 25) */
		reached[4][16] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P4 *)_this)->ChoiceEntry_chosen);
		((P4 *)_this)->ChoiceEntry_chosen = 1;
#ifdef VAR_RANGES
		logval("Customer:ChoiceEntry_chosen", ((int)((P4 *)_this)->ChoiceEntry_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: ChoiceEntry_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->ChoiceEntry_chosen = 0;
		/* merge: goto Region1region0_label(0, 17, 25) */
		reached[4][17] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 107: // STATE 18 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:592 - [(((state0==3)&&(current_event==1)))] (25:0:4 - 1)
		IfNotBlocked
		reached[4][18] = 1;
		if (!(((((int)((P4 *)_this)->state0)==3)&&(((int)((P4 *)_this)->current_event)==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P4 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->current_event = 0;
		/* merge: state0_transition = 3(25, 19, 25) */
		reached[4][19] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P4 *)_this)->state0_transition);
		((P4 *)_this)->state0_transition = 3;
#ifdef VAR_RANGES
		logval("Customer:state0_transition", ((int)((P4 *)_this)->state0_transition));
#endif
		;
		/* merge: ChoiceEntry_chosen = 1(25, 20, 25) */
		reached[4][20] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P4 *)_this)->ChoiceEntry_chosen);
		((P4 *)_this)->ChoiceEntry_chosen = 1;
#ifdef VAR_RANGES
		logval("Customer:ChoiceEntry_chosen", ((int)((P4 *)_this)->ChoiceEntry_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: ChoiceEntry_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->ChoiceEntry_chosen = 0;
		/* merge: goto Region1region0_label(0, 21, 25) */
		reached[4][21] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 108: // STATE 26 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:602 - [((state0_transition==3))] (29:0:3 - 1)
		IfNotBlocked
		reached[4][26] = 1;
		if (!((((int)((P4 *)_this)->state0_transition)==3)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((P4 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(29, 27, 29) */
		reached[4][27] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P4 *)_this)->state0_transition);
		((P4 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Customer:state0_transition", ((int)((P4 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(29, 28, 29) */
		reached[4][28] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P4 *)_this)->state0);
		((P4 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Customer:state0", ((int)((P4 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 109: // STATE 29 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:605 - [event_queues[(custProf-1)]!1,ack_in] (0:0:0 - 1)
		IfNotBlocked
		reached[4][29] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]]&2)
		{	q_S_check(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ], II);
		}
#endif
		if (q_full(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((P4 *)_this)->ack_in); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ], 0, 1, ((P4 *)_this)->ack_in, 2);
		if (q_zero(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ])) { boq = now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]; };
		_m = 2; goto P999; /* 0 */
	case 110: // STATE 30 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:606 - [state0 = 4] (0:0:1 - 1)
		IfNotBlocked
		reached[4][30] = 1;
		(trpt+1)->bup.oval = ((int)((P4 *)_this)->state0);
		((P4 *)_this)->state0 = 4;
#ifdef VAR_RANGES
		logval("Customer:state0", ((int)((P4 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 111: // STATE 31 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:607 - [((state0_transition==4))] (34:0:3 - 1)
		IfNotBlocked
		reached[4][31] = 1;
		if (!((((int)((P4 *)_this)->state0_transition)==4)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((P4 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(34, 32, 34) */
		reached[4][32] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P4 *)_this)->state0_transition);
		((P4 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Customer:state0_transition", ((int)((P4 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(34, 33, 34) */
		reached[4][33] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P4 *)_this)->state0);
		((P4 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Customer:state0", ((int)((P4 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 112: // STATE 34 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:610 - [event_queues[(custProf-1)]!1,ack_in] (0:0:0 - 1)
		IfNotBlocked
		reached[4][34] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]]&2)
		{	q_S_check(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ], II);
		}
#endif
		if (q_full(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((P4 *)_this)->ack_in); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ], 0, 1, ((P4 *)_this)->ack_in, 2);
		if (q_zero(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ])) { boq = now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]; };
		_m = 2; goto P999; /* 0 */
	case 113: // STATE 35 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:611 - [state0 = 4] (0:0:1 - 1)
		IfNotBlocked
		reached[4][35] = 1;
		(trpt+1)->bup.oval = ((int)((P4 *)_this)->state0);
		((P4 *)_this)->state0 = 4;
#ifdef VAR_RANGES
		logval("Customer:state0", ((int)((P4 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 114: // STATE 36 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:612 - [((state0_transition==2))] (49:0:5 - 1)
		IfNotBlocked
		reached[4][36] = 1;
		if (!((((int)((P4 *)_this)->state0_transition)==2)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P4 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(49, 37, 49) */
		reached[4][37] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P4 *)_this)->state0_transition);
		((P4 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Customer:state0_transition", ((int)((P4 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(49, 38, 49) */
		reached[4][38] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P4 *)_this)->completed[1]);
		((P4 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Customer:completed[1]", ((int)((P4 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(49, 39, 49) */
		reached[4][39] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P4 *)_this)->state0);
		((P4 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Customer:state0", ((int)((P4 *)_this)->state0));
#endif
		;
		/* merge: state0 = 5(49, 40, 49) */
		reached[4][40] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P4 *)_this)->state0);
		((P4 *)_this)->state0 = 5;
#ifdef VAR_RANGES
		logval("Customer:state0", ((int)((P4 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 115: // STATE 41 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:618 - [((Customer_proceedToPayment!=1))] (69:0:3 - 1)
		IfNotBlocked
		reached[4][41] = 1;
		if (!((((int)now.Customer_proceedToPayment)!=1)))
			continue;
		/* merge: state0_transition = 4(69, 42, 69) */
		reached[4][42] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P4 *)_this)->state0_transition);
		((P4 *)_this)->state0_transition = 4;
#ifdef VAR_RANGES
		logval("Customer:state0_transition", ((int)((P4 *)_this)->state0_transition));
#endif
		;
		/* merge: ChoiceEntry_chosen = 1(69, 43, 69) */
		reached[4][43] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P4 *)_this)->ChoiceEntry_chosen);
		((P4 *)_this)->ChoiceEntry_chosen = 1;
#ifdef VAR_RANGES
		logval("Customer:ChoiceEntry_chosen", ((int)((P4 *)_this)->ChoiceEntry_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: ChoiceEntry_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->ChoiceEntry_chosen = 0;
		/* merge: .(goto)(0, 50, 69) */
		reached[4][50] = 1;
		;
		/* merge: .(goto)(0, 65, 69) */
		reached[4][65] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 116: // STATE 44 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:621 - [((Customer_proceedToPayment==1))] (69:0:3 - 1)
		IfNotBlocked
		reached[4][44] = 1;
		if (!((((int)now.Customer_proceedToPayment)==1)))
			continue;
		/* merge: state0_transition = 5(69, 45, 69) */
		reached[4][45] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P4 *)_this)->state0_transition);
		((P4 *)_this)->state0_transition = 5;
#ifdef VAR_RANGES
		logval("Customer:state0_transition", ((int)((P4 *)_this)->state0_transition));
#endif
		;
		/* merge: ChoiceEntry_chosen = 1(69, 46, 69) */
		reached[4][46] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P4 *)_this)->ChoiceEntry_chosen);
		((P4 *)_this)->ChoiceEntry_chosen = 1;
#ifdef VAR_RANGES
		logval("Customer:ChoiceEntry_chosen", ((int)((P4 *)_this)->ChoiceEntry_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: ChoiceEntry_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->ChoiceEntry_chosen = 0;
		/* merge: .(goto)(0, 50, 69) */
		reached[4][50] = 1;
		;
		/* merge: .(goto)(0, 65, 69) */
		reached[4][65] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 117: // STATE 48 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:625 - [assert(0)] (0:0:0 - 1)
		IfNotBlocked
		reached[4][48] = 1;
		spin_assert(0, "0", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 118: // STATE 51 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:627 - [((state0_transition==5))] (54:0:3 - 1)
		IfNotBlocked
		reached[4][51] = 1;
		if (!((((int)((P4 *)_this)->state0_transition)==5)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((P4 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(54, 52, 54) */
		reached[4][52] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P4 *)_this)->state0_transition);
		((P4 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Customer:state0_transition", ((int)((P4 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(54, 53, 54) */
		reached[4][53] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P4 *)_this)->state0);
		((P4 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Customer:state0", ((int)((P4 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 119: // STATE 54 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:630 - [event_queues[(custProf-1)]!2,ack_in] (0:0:0 - 1)
		IfNotBlocked
		reached[4][54] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]]&2)
		{	q_S_check(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ], II);
		}
#endif
		if (q_full(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((P4 *)_this)->ack_in); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ], 0, 2, ((P4 *)_this)->ack_in, 2);
		if (q_zero(now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ])) { boq = now.event_queues[ Index((((int)((P4 *)_this)->custProf)-1), 15) ]; };
		_m = 2; goto P999; /* 0 */
	case 120: // STATE 55 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:631 - [ack_in?_] (69:0:2 - 1)
		reached[4][55] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P4 *)_this)->ack_in]&1)
		{	q_R_check(((P4 *)_this)->ack_in, II);
		}
#endif
		if (q_zero(((P4 *)_this)->ack_in))
		{	if (boq != ((P4 *)_this)->ack_in) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P4 *)_this)->ack_in) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = qrecv(((P4 *)_this)->ack_in, XX-1, 0, 0);
		;
		qrecv(((P4 *)_this)->ack_in, XX-1, 0, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P4 *)_this)->ack_in);
			sprintf(simtmp, "%d", ((int)_)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P4 *)_this)->ack_in))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		/* merge: state0 = 3(0, 56, 69) */
		reached[4][56] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P4 *)_this)->state0);
		((P4 *)_this)->state0 = 3;
#ifdef VAR_RANGES
		logval("Customer:state0", ((int)((P4 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 65, 69) */
		reached[4][65] = 1;
		;
		_m = 4; goto P999; /* 2 */
	case 121: // STATE 57 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:633 - [((state0_transition==1))] (62:0:5 - 1)
		IfNotBlocked
		reached[4][57] = 1;
		if (!((((int)((P4 *)_this)->state0_transition)==1)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P4 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P4 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(62, 58, 62) */
		reached[4][58] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P4 *)_this)->state0_transition);
		((P4 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Customer:state0_transition", ((int)((P4 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(62, 59, 62) */
		reached[4][59] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P4 *)_this)->state0);
		((P4 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Customer:state0", ((int)((P4 *)_this)->state0));
#endif
		;
		/* merge: state0 = 2(62, 60, 62) */
		reached[4][60] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P4 *)_this)->state0);
		((P4 *)_this)->state0 = 2;
#ifdef VAR_RANGES
		logval("Customer:state0", ((int)((P4 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(62, 61, 62) */
		reached[4][61] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P4 *)_this)->completed[1]);
		((P4 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Customer:completed[1]", ((int)((P4 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 122: // STATE 62 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:638 - [internal_queue!2] (0:0:0 - 1)
		IfNotBlocked
		reached[4][62] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P4 *)_this)->internal_queue]&2)
		{	q_S_check(((P4 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P4 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P4 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P4 *)_this)->internal_queue, 0, 2, 0, 1);
		if (q_zero(((P4 *)_this)->internal_queue)) { boq = ((P4 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 123: // STATE 66 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:642 - [((state0_transition!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[4][66] = 1;
		if (!((((int)((P4 *)_this)->state0_transition)!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 124: // STATE 71 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:646 - [ChoiceEntry_chosen = 0] (0:76:1 - 2)
		IfNotBlocked
		reached[4][71] = 1;
		(trpt+1)->bup.oval = ((int)((P4 *)_this)->ChoiceEntry_chosen);
		((P4 *)_this)->ChoiceEntry_chosen = 0;
#ifdef VAR_RANGES
		logval("Customer:ChoiceEntry_chosen", ((int)((P4 *)_this)->ChoiceEntry_chosen));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 125: // STATE 72 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:648 - [((state0!=4))] (7:0:0 - 1)
		IfNotBlocked
		reached[4][72] = 1;
		if (!((((int)((P4 *)_this)->state0)!=4)))
			continue;
		/* merge: goto main(0, 73, 7) */
		reached[4][73] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 126: // STATE 79 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:655 - [(0)] (0:0:0 - 2)
		IfNotBlocked
		reached[4][79] = 1;
		if (!(0))
			continue;
		_m = 3; goto P999; /* 0 */
	case 127: // STATE 80 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:656 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[4][80] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC ShoppingCart */
	case 128: // STATE 1 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:492 - [state0 = 1] (0:45:2 - 1)
		IfNotBlocked
		reached[3][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)_this)->state0);
		((P3 *)_this)->state0 = 1;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0", ((int)((P3 *)_this)->state0));
#endif
		;
		/* merge: state0_transition = 1(45, 2, 45) */
		reached[3][2] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)_this)->state0_transition);
		((P3 *)_this)->state0_transition = 1;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0_transition", ((int)((P3 *)_this)->state0_transition));
#endif
		;
		/* merge: goto transitionFiring(0, 3, 45) */
		reached[3][3] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 129: // STATE 5 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:497 - [current_event = 0] (0:0:1 - 3)
		IfNotBlocked
		reached[3][5] = 1;
		(trpt+1)->bup.oval = ((int)((P3 *)_this)->current_event);
		((P3 *)_this)->current_event = 0;
#ifdef VAR_RANGES
		logval("ShoppingCart:current_event", ((int)((P3 *)_this)->current_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 130: // STATE 6 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:499 - [(internal_queue?[current_event])] (0:0:0 - 1)
		IfNotBlocked
		reached[3][6] = 1;
		if (!(
#ifndef XUSAFE
		(!(q_claim[((P3 *)_this)->internal_queue]&1) || q_R_check(((P3 *)_this)->internal_queue, II)) &&
		(!(q_claim[((P3 *)_this)->internal_queue]&2) || q_S_check(((P3 *)_this)->internal_queue, II)) &&
#endif
		not_RV(((P3 *)_this)->internal_queue) && \
		(q_len(((P3 *)_this)->internal_queue) > 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 131: // STATE 7 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:500 - [internal_queue?current_event] (0:0:1 - 1)
		reached[3][7] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P3 *)_this)->internal_queue]&1)
		{	q_R_check(((P3 *)_this)->internal_queue, II);
		}
#endif
		if (q_zero(((P3 *)_this)->internal_queue))
		{	if (boq != ((P3 *)_this)->internal_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P3 *)_this)->internal_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.oval = ((int)((P3 *)_this)->current_event);
		;
		((P3 *)_this)->current_event = qrecv(((P3 *)_this)->internal_queue, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("ShoppingCart:current_event", ((int)((P3 *)_this)->current_event));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P3 *)_this)->internal_queue);
			sprintf(simtmp, "%d", ((int)((P3 *)_this)->current_event)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P3 *)_this)->internal_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 132: // STATE 9 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:502 - [event_queue?current_event,ack_out] (0:0:2 - 1)
		reached[3][9] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P3 *)_this)->event_queue]&1)
		{	q_R_check(((P3 *)_this)->event_queue, II);
		}
#endif
		if (q_zero(((P3 *)_this)->event_queue))
		{	if (boq != ((P3 *)_this)->event_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P3 *)_this)->event_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P3 *)_this)->current_event);
		(trpt+1)->bup.ovals[1] = ((P3 *)_this)->ack_out;
		;
		((P3 *)_this)->current_event = qrecv(((P3 *)_this)->event_queue, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("ShoppingCart:current_event", ((int)((P3 *)_this)->current_event));
#endif
		;
		((P3 *)_this)->ack_out = qrecv(((P3 *)_this)->event_queue, XX-1, 1, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P3 *)_this)->event_queue);
			sprintf(simtmp, "%d", ((int)((P3 *)_this)->current_event)); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((P3 *)_this)->ack_out); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P3 *)_this)->event_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 133: // STATE 12 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:506 - [((((state0==2)&&(current_event==1))&&(completed[1]==1)))] (17:0:6 - 1)
		IfNotBlocked
		reached[3][12] = 1;
		if (!((((((int)((P3 *)_this)->state0)==2)&&(((int)((P3 *)_this)->current_event)==1))&&(((int)((P3 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0 */  (trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P3 *)_this)->state0;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->state0 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P3 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->current_event = 0;
		/* merge: completed[1] = 0(17, 13, 17) */
		reached[3][13] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)_this)->completed[1]);
		((P3 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("ShoppingCart:completed[1]", ((int)((P3 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(17, 14, 17) */
		reached[3][14] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)_this)->state0);
		((P3 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0", ((int)((P3 *)_this)->state0));
#endif
		;
		/* merge: state0 = 3(17, 15, 17) */
		reached[3][15] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P3 *)_this)->state0);
		((P3 *)_this)->state0 = 3;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0", ((int)((P3 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(17, 16, 17) */
		reached[3][16] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P3 *)_this)->completed[1]);
		((P3 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("ShoppingCart:completed[1]", ((int)((P3 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 134: // STATE 17 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:511 - [internal_queue!2] (0:0:0 - 1)
		IfNotBlocked
		reached[3][17] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P3 *)_this)->internal_queue]&2)
		{	q_S_check(((P3 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P3 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P3 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P3 *)_this)->internal_queue, 0, 2, 0, 1);
		if (q_zero(((P3 *)_this)->internal_queue)) { boq = ((P3 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 135: // STATE 19 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:513 - [((((state0==3)&&(current_event==2))&&(completed[1]==1)))] (24:0:6 - 1)
		IfNotBlocked
		reached[3][19] = 1;
		if (!((((((int)((P3 *)_this)->state0)==3)&&(((int)((P3 *)_this)->current_event)==2))&&(((int)((P3 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0 */  (trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P3 *)_this)->state0;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->state0 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P3 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->current_event = 0;
		/* merge: completed[1] = 0(24, 20, 24) */
		reached[3][20] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)_this)->completed[1]);
		((P3 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("ShoppingCart:completed[1]", ((int)((P3 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(24, 21, 24) */
		reached[3][21] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)_this)->state0);
		((P3 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0", ((int)((P3 *)_this)->state0));
#endif
		;
		/* merge: state0 = 4(24, 22, 24) */
		reached[3][22] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P3 *)_this)->state0);
		((P3 *)_this)->state0 = 4;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0", ((int)((P3 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(24, 23, 24) */
		reached[3][23] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P3 *)_this)->completed[1]);
		((P3 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("ShoppingCart:completed[1]", ((int)((P3 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 136: // STATE 24 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:518 - [internal_queue!3] (0:0:0 - 1)
		IfNotBlocked
		reached[3][24] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P3 *)_this)->internal_queue]&2)
		{	q_S_check(((P3 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P3 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P3 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P3 *)_this)->internal_queue, 0, 3, 0, 1);
		if (q_zero(((P3 *)_this)->internal_queue)) { boq = ((P3 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 137: // STATE 26 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:520 - [((((state0==4)&&(current_event==3))&&(completed[1]==1)))] (32:0:2 - 1)
		IfNotBlocked
		reached[3][26] = 1;
		if (!((((((int)((P3 *)_this)->state0)==4)&&(((int)((P3 *)_this)->current_event)==3))&&(((int)((P3 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P3 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->current_event = 0;
		/* merge: state0_transition = 2(0, 27, 32) */
		reached[3][27] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)_this)->state0_transition);
		((P3 *)_this)->state0_transition = 2;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0_transition", ((int)((P3 *)_this)->state0_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 28, 32) */
		reached[3][28] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 138: // STATE 33 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:529 - [((state0_transition==2))] (50:0:5 - 1)
		IfNotBlocked
		reached[3][33] = 1;
		if (!((((int)((P3 *)_this)->state0_transition)==2)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P3 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(50, 34, 50) */
		reached[3][34] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)_this)->state0_transition);
		((P3 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0_transition", ((int)((P3 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(50, 35, 50) */
		reached[3][35] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)_this)->completed[1]);
		((P3 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("ShoppingCart:completed[1]", ((int)((P3 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(50, 36, 50) */
		reached[3][36] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)_this)->state0);
		((P3 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0", ((int)((P3 *)_this)->state0));
#endif
		;
		/* merge: state0 = 5(50, 37, 50) */
		reached[3][37] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P3 *)_this)->state0);
		((P3 *)_this)->state0 = 5;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0", ((int)((P3 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 46, 50) */
		reached[3][46] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 139: // STATE 38 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:534 - [((state0_transition==1))] (43:0:5 - 1)
		IfNotBlocked
		reached[3][38] = 1;
		if (!((((int)((P3 *)_this)->state0_transition)==1)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P3 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P3 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(43, 39, 43) */
		reached[3][39] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P3 *)_this)->state0_transition);
		((P3 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0_transition", ((int)((P3 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(43, 40, 43) */
		reached[3][40] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P3 *)_this)->state0);
		((P3 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0", ((int)((P3 *)_this)->state0));
#endif
		;
		/* merge: state0 = 2(43, 41, 43) */
		reached[3][41] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P3 *)_this)->state0);
		((P3 *)_this)->state0 = 2;
#ifdef VAR_RANGES
		logval("ShoppingCart:state0", ((int)((P3 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(43, 42, 43) */
		reached[3][42] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P3 *)_this)->completed[1]);
		((P3 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("ShoppingCart:completed[1]", ((int)((P3 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 140: // STATE 43 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:539 - [internal_queue!1] (0:0:0 - 1)
		IfNotBlocked
		reached[3][43] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P3 *)_this)->internal_queue]&2)
		{	q_S_check(((P3 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P3 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P3 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P3 *)_this)->internal_queue, 0, 1, 0, 1);
		if (q_zero(((P3 *)_this)->internal_queue)) { boq = ((P3 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 141: // STATE 47 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:543 - [((state0_transition!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[3][47] = 1;
		if (!((((int)((P3 *)_this)->state0_transition)!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 142: // STATE 52 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:548 - [((state0!=5))] (5:0:0 - 1)
		IfNotBlocked
		reached[3][52] = 1;
		if (!((((int)((P3 *)_this)->state0)!=5)))
			continue;
		/* merge: goto main(0, 53, 5) */
		reached[3][53] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 143: // STATE 59 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:555 - [(0)] (0:0:0 - 2)
		IfNotBlocked
		reached[3][59] = 1;
		if (!(0))
			continue;
		_m = 3; goto P999; /* 0 */
	case 144: // STATE 60 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:556 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[3][60] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Payment */
	case 145: // STATE 1 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:422 - [state0 = 1] (0:38:2 - 1)
		IfNotBlocked
		reached[2][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P2 *)_this)->state0);
		((P2 *)_this)->state0 = 1;
#ifdef VAR_RANGES
		logval("Payment:state0", ((int)((P2 *)_this)->state0));
#endif
		;
		/* merge: state0_transition = 1(38, 2, 38) */
		reached[2][2] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P2 *)_this)->state0_transition);
		((P2 *)_this)->state0_transition = 1;
#ifdef VAR_RANGES
		logval("Payment:state0_transition", ((int)((P2 *)_this)->state0_transition));
#endif
		;
		/* merge: goto transitionFiring(0, 3, 38) */
		reached[2][3] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 146: // STATE 5 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:427 - [current_event = 0] (0:0:1 - 2)
		IfNotBlocked
		reached[2][5] = 1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->current_event);
		((P2 *)_this)->current_event = 0;
#ifdef VAR_RANGES
		logval("Payment:current_event", ((int)((P2 *)_this)->current_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 147: // STATE 6 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:429 - [(internal_queue?[current_event])] (0:0:0 - 1)
		IfNotBlocked
		reached[2][6] = 1;
		if (!(
#ifndef XUSAFE
		(!(q_claim[((P2 *)_this)->internal_queue]&1) || q_R_check(((P2 *)_this)->internal_queue, II)) &&
		(!(q_claim[((P2 *)_this)->internal_queue]&2) || q_S_check(((P2 *)_this)->internal_queue, II)) &&
#endif
		not_RV(((P2 *)_this)->internal_queue) && \
		(q_len(((P2 *)_this)->internal_queue) > 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 148: // STATE 7 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:430 - [internal_queue?current_event] (0:0:1 - 1)
		reached[2][7] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P2 *)_this)->internal_queue]&1)
		{	q_R_check(((P2 *)_this)->internal_queue, II);
		}
#endif
		if (q_zero(((P2 *)_this)->internal_queue))
		{	if (boq != ((P2 *)_this)->internal_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P2 *)_this)->internal_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.oval = ((int)((P2 *)_this)->current_event);
		;
		((P2 *)_this)->current_event = qrecv(((P2 *)_this)->internal_queue, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("Payment:current_event", ((int)((P2 *)_this)->current_event));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P2 *)_this)->internal_queue);
			sprintf(simtmp, "%d", ((int)((P2 *)_this)->current_event)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P2 *)_this)->internal_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 149: // STATE 9 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:432 - [event_queue?current_event,ack_out] (0:0:2 - 1)
		reached[2][9] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P2 *)_this)->event_queue]&1)
		{	q_R_check(((P2 *)_this)->event_queue, II);
		}
#endif
		if (q_zero(((P2 *)_this)->event_queue))
		{	if (boq != ((P2 *)_this)->event_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P2 *)_this)->event_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P2 *)_this)->current_event);
		(trpt+1)->bup.ovals[1] = ((P2 *)_this)->ack_out;
		;
		((P2 *)_this)->current_event = qrecv(((P2 *)_this)->event_queue, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("Payment:current_event", ((int)((P2 *)_this)->current_event));
#endif
		;
		((P2 *)_this)->ack_out = qrecv(((P2 *)_this)->event_queue, XX-1, 1, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P2 *)_this)->event_queue);
			sprintf(simtmp, "%d", ((int)((P2 *)_this)->current_event)); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((P2 *)_this)->ack_out); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P2 *)_this)->event_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 150: // STATE 12 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:436 - [((((state0==2)&&(current_event==1))&&(completed[1]==1)))] (17:0:6 - 1)
		IfNotBlocked
		reached[2][12] = 1;
		if (!((((((int)((P2 *)_this)->state0)==2)&&(((int)((P2 *)_this)->current_event)==1))&&(((int)((P2 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0 */  (trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P2 *)_this)->state0;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->state0 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P2 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->current_event = 0;
		/* merge: completed[1] = 0(17, 13, 17) */
		reached[2][13] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P2 *)_this)->completed[1]);
		((P2 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Payment:completed[1]", ((int)((P2 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(17, 14, 17) */
		reached[2][14] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P2 *)_this)->state0);
		((P2 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Payment:state0", ((int)((P2 *)_this)->state0));
#endif
		;
		/* merge: state0 = 3(17, 15, 17) */
		reached[2][15] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P2 *)_this)->state0);
		((P2 *)_this)->state0 = 3;
#ifdef VAR_RANGES
		logval("Payment:state0", ((int)((P2 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(17, 16, 17) */
		reached[2][16] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P2 *)_this)->completed[1]);
		((P2 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Payment:completed[1]", ((int)((P2 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 151: // STATE 17 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:441 - [internal_queue!2] (0:0:0 - 1)
		IfNotBlocked
		reached[2][17] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P2 *)_this)->internal_queue]&2)
		{	q_S_check(((P2 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P2 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P2 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P2 *)_this)->internal_queue, 0, 2, 0, 1);
		if (q_zero(((P2 *)_this)->internal_queue)) { boq = ((P2 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 152: // STATE 19 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:443 - [((((state0==3)&&(current_event==2))&&(completed[1]==1)))] (25:0:2 - 1)
		IfNotBlocked
		reached[2][19] = 1;
		if (!((((((int)((P2 *)_this)->state0)==3)&&(((int)((P2 *)_this)->current_event)==2))&&(((int)((P2 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P2 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->current_event = 0;
		/* merge: state0_transition = 2(0, 20, 25) */
		reached[2][20] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P2 *)_this)->state0_transition);
		((P2 *)_this)->state0_transition = 2;
#ifdef VAR_RANGES
		logval("Payment:state0_transition", ((int)((P2 *)_this)->state0_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 21, 25) */
		reached[2][21] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 153: // STATE 26 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:452 - [((state0_transition==1))] (31:0:5 - 1)
		IfNotBlocked
		reached[2][26] = 1;
		if (!((((int)((P2 *)_this)->state0_transition)==1)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P2 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(31, 27, 31) */
		reached[2][27] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P2 *)_this)->state0_transition);
		((P2 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Payment:state0_transition", ((int)((P2 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(31, 28, 31) */
		reached[2][28] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P2 *)_this)->state0);
		((P2 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Payment:state0", ((int)((P2 *)_this)->state0));
#endif
		;
		/* merge: state0 = 2(31, 29, 31) */
		reached[2][29] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P2 *)_this)->state0);
		((P2 *)_this)->state0 = 2;
#ifdef VAR_RANGES
		logval("Payment:state0", ((int)((P2 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(31, 30, 31) */
		reached[2][30] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P2 *)_this)->completed[1]);
		((P2 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Payment:completed[1]", ((int)((P2 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 154: // STATE 31 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:457 - [internal_queue!1] (0:0:0 - 1)
		IfNotBlocked
		reached[2][31] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P2 *)_this)->internal_queue]&2)
		{	q_S_check(((P2 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P2 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P2 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P2 *)_this)->internal_queue, 0, 1, 0, 1);
		if (q_zero(((P2 *)_this)->internal_queue)) { boq = ((P2 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 155: // STATE 32 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:458 - [((state0_transition==2))] (43:0:5 - 1)
		IfNotBlocked
		reached[2][32] = 1;
		if (!((((int)((P2 *)_this)->state0_transition)==2)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P2 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P2 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(43, 33, 43) */
		reached[2][33] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P2 *)_this)->state0_transition);
		((P2 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Payment:state0_transition", ((int)((P2 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(43, 34, 43) */
		reached[2][34] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P2 *)_this)->completed[1]);
		((P2 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Payment:completed[1]", ((int)((P2 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(43, 35, 43) */
		reached[2][35] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P2 *)_this)->state0);
		((P2 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Payment:state0", ((int)((P2 *)_this)->state0));
#endif
		;
		/* merge: state0 = 4(43, 36, 43) */
		reached[2][36] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P2 *)_this)->state0);
		((P2 *)_this)->state0 = 4;
#ifdef VAR_RANGES
		logval("Payment:state0", ((int)((P2 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 39, 43) */
		reached[2][39] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 156: // STATE 40 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:466 - [((state0_transition!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[2][40] = 1;
		if (!((((int)((P2 *)_this)->state0_transition)!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 157: // STATE 45 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:471 - [((state0!=4))] (5:0:0 - 1)
		IfNotBlocked
		reached[2][45] = 1;
		if (!((((int)((P2 *)_this)->state0)!=4)))
			continue;
		/* merge: goto main(0, 46, 5) */
		reached[2][46] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 158: // STATE 52 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:478 - [(0)] (0:0:0 - 2)
		IfNotBlocked
		reached[2][52] = 1;
		if (!(0))
			continue;
		_m = 3; goto P999; /* 0 */
	case 159: // STATE 53 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:479 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[2][53] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Role */
	case 160: // STATE 1 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:252 - [webuser = initialiser_webuser0] (0:137:5 - 1)
		IfNotBlocked
		reached[1][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->webuser);
		((P1 *)_this)->webuser = ((int)((P1 *)_this)->initialiser_webuser0);
#ifdef VAR_RANGES
		logval("Role:webuser", ((int)((P1 *)_this)->webuser));
#endif
		;
		/* merge: state0 = 1(137, 2, 137) */
		reached[1][2] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 1;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: state0_transition = 1(137, 3, 137) */
		reached[1][3] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 1;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: Logging_chosen = 1(137, 4, 137) */
		reached[1][4] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 1;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: Logging_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->Logging_chosen = 0;
		/* merge: goto transitionFiring(0, 5, 137) */
		reached[1][5] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 161: // STATE 7 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:259 - [current_event = 0] (0:0:1 - 2)
		IfNotBlocked
		reached[1][7] = 1;
		(trpt+1)->bup.oval = ((int)((P1 *)_this)->current_event);
		((P1 *)_this)->current_event = 0;
#ifdef VAR_RANGES
		logval("Role:current_event", ((int)((P1 *)_this)->current_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 162: // STATE 8 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:261 - [(internal_queue?[current_event])] (0:0:0 - 1)
		IfNotBlocked
		reached[1][8] = 1;
		if (!(
#ifndef XUSAFE
		(!(q_claim[((P1 *)_this)->internal_queue]&1) || q_R_check(((P1 *)_this)->internal_queue, II)) &&
		(!(q_claim[((P1 *)_this)->internal_queue]&2) || q_S_check(((P1 *)_this)->internal_queue, II)) &&
#endif
		not_RV(((P1 *)_this)->internal_queue) && \
		(q_len(((P1 *)_this)->internal_queue) > 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 163: // STATE 9 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:262 - [internal_queue?current_event] (0:0:1 - 1)
		reached[1][9] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P1 *)_this)->internal_queue]&1)
		{	q_R_check(((P1 *)_this)->internal_queue, II);
		}
#endif
		if (q_zero(((P1 *)_this)->internal_queue))
		{	if (boq != ((P1 *)_this)->internal_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P1 *)_this)->internal_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.oval = ((int)((P1 *)_this)->current_event);
		;
		((P1 *)_this)->current_event = qrecv(((P1 *)_this)->internal_queue, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("Role:current_event", ((int)((P1 *)_this)->current_event));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P1 *)_this)->internal_queue);
			sprintf(simtmp, "%d", ((int)((P1 *)_this)->current_event)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P1 *)_this)->internal_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 164: // STATE 11 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:264 - [event_queue?current_event,ack_out] (0:0:2 - 1)
		reached[1][11] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P1 *)_this)->event_queue]&1)
		{	q_R_check(((P1 *)_this)->event_queue, II);
		}
#endif
		if (q_zero(((P1 *)_this)->event_queue))
		{	if (boq != ((P1 *)_this)->event_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P1 *)_this)->event_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->current_event);
		(trpt+1)->bup.ovals[1] = ((P1 *)_this)->ack_out;
		;
		((P1 *)_this)->current_event = qrecv(((P1 *)_this)->event_queue, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("Role:current_event", ((int)((P1 *)_this)->current_event));
#endif
		;
		((P1 *)_this)->ack_out = qrecv(((P1 *)_this)->event_queue, XX-1, 1, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P1 *)_this)->event_queue);
			sprintf(simtmp, "%d", ((int)((P1 *)_this)->current_event)); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((P1 *)_this)->ack_out); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P1 *)_this)->event_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 165: // STATE 14 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:268 - [(((state0==2)&&(current_event==1)))] (0:0:2 - 1)
		IfNotBlocked
		reached[1][14] = 1;
		if (!(((((int)((P1 *)_this)->state0)==2)&&(((int)((P1 *)_this)->current_event)==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0 */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P1 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->current_event = 0;
		_m = 3; goto P999; /* 0 */
	case 166: // STATE 15 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:269 - [ack_out!1] (0:0:0 - 1)
		IfNotBlocked
		reached[1][15] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P1 *)_this)->ack_out]&2)
		{	q_S_check(((P1 *)_this)->ack_out, II);
		}
#endif
		if (q_full(((P1 *)_this)->ack_out))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P1 *)_this)->ack_out);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P1 *)_this)->ack_out, 0, 1, 0, 1);
		if (q_zero(((P1 *)_this)->ack_out)) { boq = ((P1 *)_this)->ack_out; };
		_m = 2; goto P999; /* 0 */
	case 167: // STATE 16 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:270 - [state0 = 0] (0:20:4 - 1)
		IfNotBlocked
		reached[1][16] = 1;
		(trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: Role_tries = 0(20, 17, 20) */
		reached[1][17] = 1;
		(trpt+1)->bup.ovals[1] = now.Role_tries;
		now.Role_tries = 0;
#ifdef VAR_RANGES
		logval("Role_tries", now.Role_tries);
#endif
		;
		/* merge: state0 = 3(20, 18, 20) */
		reached[1][18] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 3;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(20, 19, 20) */
		reached[1][19] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)_this)->completed[1]);
		((P1 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Role:completed[1]", ((int)((P1 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 3 */
	case 168: // STATE 20 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:274 - [internal_queue!2] (0:0:0 - 1)
		IfNotBlocked
		reached[1][20] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P1 *)_this)->internal_queue]&2)
		{	q_S_check(((P1 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P1 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P1 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P1 *)_this)->internal_queue, 0, 2, 0, 1);
		if (q_zero(((P1 *)_this)->internal_queue)) { boq = ((P1 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 169: // STATE 22 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:276 - [((((state0==3)&&(current_event==2))&&(completed[1]==1)))] (45:0:3 - 1)
		IfNotBlocked
		reached[1][22] = 1;
		if (!((((((int)((P1 *)_this)->state0)==3)&&(((int)((P1 *)_this)->current_event)==2))&&(((int)((P1 *)_this)->completed[1])==1))))
			continue;
		/* merge: state0_transition = 2(45, 23, 45) */
		reached[1][23] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 2;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: Logging_chosen = 1(45, 24, 45) */
		reached[1][24] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 1;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: Logging_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->Logging_chosen = 0;
		/* merge: goto Region1region0_label(0, 25, 45) */
		reached[1][25] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 170: // STATE 26 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:280 - [((((state0==4)&&(current_event==3))&&(completed[1]==1)))] (45:0:3 - 1)
		IfNotBlocked
		reached[1][26] = 1;
		if (!((((((int)((P1 *)_this)->state0)==4)&&(((int)((P1 *)_this)->current_event)==3))&&(((int)((P1 *)_this)->completed[1])==1))))
			continue;
		/* merge: state0_transition = 3(45, 27, 45) */
		reached[1][27] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 3;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: Logging_chosen = 1(45, 28, 45) */
		reached[1][28] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 1;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: Logging_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->Logging_chosen = 0;
		/* merge: goto Region1region0_label(0, 29, 45) */
		reached[1][29] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 171: // STATE 30 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:284 - [((((state0==5)&&(current_event==4))&&(completed[1]==1)))] (45:0:3 - 1)
		IfNotBlocked
		reached[1][30] = 1;
		if (!((((((int)((P1 *)_this)->state0)==5)&&(((int)((P1 *)_this)->current_event)==4))&&(((int)((P1 *)_this)->completed[1])==1))))
			continue;
		/* merge: state0_transition = 4(45, 31, 45) */
		reached[1][31] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 4;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: Logging_chosen = 1(45, 32, 45) */
		reached[1][32] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 1;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: Logging_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->Logging_chosen = 0;
		/* merge: goto Region1region0_label(0, 33, 45) */
		reached[1][33] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 172: // STATE 34 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:288 - [((((state0==6)&&(current_event==5))&&(completed[1]==1)))] (45:0:3 - 1)
		IfNotBlocked
		reached[1][34] = 1;
		if (!((((((int)((P1 *)_this)->state0)==6)&&(((int)((P1 *)_this)->current_event)==5))&&(((int)((P1 *)_this)->completed[1])==1))))
			continue;
		/* merge: state0_transition = 5(45, 35, 45) */
		reached[1][35] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 5;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: Logging_chosen = 1(45, 36, 45) */
		reached[1][36] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 1;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: Logging_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->Logging_chosen = 0;
		/* merge: goto Region1region0_label(0, 37, 45) */
		reached[1][37] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 173: // STATE 38 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:292 - [((((state0==7)&&(current_event==6))&&(completed[1]==1)))] (45:0:3 - 1)
		IfNotBlocked
		reached[1][38] = 1;
		if (!((((((int)((P1 *)_this)->state0)==7)&&(((int)((P1 *)_this)->current_event)==6))&&(((int)((P1 *)_this)->completed[1])==1))))
			continue;
		/* merge: state0_transition = 6(45, 39, 45) */
		reached[1][39] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 6;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: Logging_chosen = 1(45, 40, 45) */
		reached[1][40] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 1;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: Logging_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->Logging_chosen = 0;
		/* merge: goto Region1region0_label(0, 41, 45) */
		reached[1][41] = 1;
		;
		_m = 3; goto P999; /* 3 */
	case 174: // STATE 46 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:301 - [((current_event==1))] (0:0:1 - 1)
		IfNotBlocked
		reached[1][46] = 1;
		if (!((((int)((P1 *)_this)->current_event)==1)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.oval = ((P1 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->current_event = 0;
		_m = 3; goto P999; /* 0 */
	case 175: // STATE 47 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:302 - [ack_out!1] (0:0:0 - 1)
		IfNotBlocked
		reached[1][47] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P1 *)_this)->ack_out]&2)
		{	q_S_check(((P1 *)_this)->ack_out, II);
		}
#endif
		if (q_full(((P1 *)_this)->ack_out))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P1 *)_this)->ack_out);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P1 *)_this)->ack_out, 0, 1, 0, 1);
		if (q_zero(((P1 *)_this)->ack_out)) { boq = ((P1 *)_this)->ack_out; };
		_m = 2; goto P999; /* 0 */
	case 176: // STATE 51 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:307 - [((state0_transition==7))] (56:0:5 - 1)
		IfNotBlocked
		reached[1][51] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)==7)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(56, 52, 56) */
		reached[1][52] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(56, 53, 56) */
		reached[1][53] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: state0 = 6(56, 54, 56) */
		reached[1][54] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 6;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(56, 55, 56) */
		reached[1][55] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P1 *)_this)->completed[1]);
		((P1 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Role:completed[1]", ((int)((P1 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 177: // STATE 56 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:312 - [internal_queue!5] (0:0:0 - 1)
		IfNotBlocked
		reached[1][56] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P1 *)_this)->internal_queue]&2)
		{	q_S_check(((P1 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P1 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P1 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 5); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P1 *)_this)->internal_queue, 0, 5, 0, 1);
		if (q_zero(((P1 *)_this)->internal_queue)) { boq = ((P1 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 178: // STATE 57 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:313 - [((state0_transition==1))] (142:0:4 - 1)
		IfNotBlocked
		reached[1][57] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)==1)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(4);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(142, 58, 142) */
		reached[1][58] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(142, 59, 142) */
		reached[1][59] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: state0 = 2(142, 60, 142) */
		reached[1][60] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 2;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 138, 142) */
		reached[1][138] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 179: // STATE 61 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:317 - [((state0_transition==2))] (78:0:6 - 1)
		IfNotBlocked
		reached[1][61] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)==2)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(78, 62, 78) */
		reached[1][62] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(78, 63, 78) */
		reached[1][63] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->completed[1]);
		((P1 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Role:completed[1]", ((int)((P1 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(78, 64, 78) */
		reached[1][64] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: Role_tries = (Role_tries+1)(78, 65, 78) */
		reached[1][65] = 1;
		(trpt+1)->bup.ovals[4] = now.Role_tries;
		now.Role_tries = (now.Role_tries+1);
#ifdef VAR_RANGES
		logval("Role_tries", now.Role_tries);
#endif
		;
		/* merge: state0 = 8(78, 66, 78) */
		reached[1][66] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 8;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 5 */
	case 180: // STATE 67 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:324 - [(( (((Role_validEntry==0)==0)) -> (0) : ((Role_tries>2)) ))] (142:0:3 - 1)
		IfNotBlocked
		reached[1][67] = 1;
		if (!(( (((((int)now.Role_validEntry)==0)==0)) ? (0) : ((now.Role_tries>2)) )))
			continue;
		/* merge: state0_transition = 8(142, 68, 142) */
		reached[1][68] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 8;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: Logging_chosen = 1(142, 69, 142) */
		reached[1][69] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 1;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: Logging_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->Logging_chosen = 0;
		/* merge: .(goto)(0, 79, 142) */
		reached[1][79] = 1;
		;
		/* merge: .(goto)(0, 138, 142) */
		reached[1][138] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 181: // STATE 70 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:327 - [(( (((Role_validEntry==1)==0)) -> (0) : ((Role_tries<3)) ))] (142:0:3 - 1)
		IfNotBlocked
		reached[1][70] = 1;
		if (!(( (((((int)now.Role_validEntry)==1)==0)) ? (0) : ((now.Role_tries<3)) )))
			continue;
		/* merge: state0_transition = 9(142, 71, 142) */
		reached[1][71] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 9;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: Logging_chosen = 1(142, 72, 142) */
		reached[1][72] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 1;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: Logging_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->Logging_chosen = 0;
		/* merge: .(goto)(0, 79, 142) */
		reached[1][79] = 1;
		;
		/* merge: .(goto)(0, 138, 142) */
		reached[1][138] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 182: // STATE 73 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:330 - [(( ((( (((Role_validEntry!=0)==1)) -> (1) : ((Role_tries<=2)) )==0)) -> (0) : (( (((Role_validEntry!=1)==1)) -> (1) : ((Role_tries>=3)) )) ))] (142:0:3 - 1)
		IfNotBlocked
		reached[1][73] = 1;
		if (!(( ((( (((((int)now.Role_validEntry)!=0)==1)) ? (1) : ((now.Role_tries<=2)) )==0)) ? (0) : (( (((((int)now.Role_validEntry)!=1)==1)) ? (1) : ((now.Role_tries>=3)) )) )))
			continue;
		/* merge: state0_transition = 10(142, 74, 142) */
		reached[1][74] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 10;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: Logging_chosen = 1(142, 75, 142) */
		reached[1][75] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 1;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: Logging_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->Logging_chosen = 0;
		/* merge: .(goto)(0, 79, 142) */
		reached[1][79] = 1;
		;
		/* merge: .(goto)(0, 138, 142) */
		reached[1][138] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 183: // STATE 77 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:334 - [assert(0)] (0:0:0 - 1)
		IfNotBlocked
		reached[1][77] = 1;
		spin_assert(0, "0", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 184: // STATE 80 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:336 - [((state0_transition==8))] (83:0:3 - 1)
		IfNotBlocked
		reached[1][80] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)==8)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(83, 81, 83) */
		reached[1][81] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(83, 82, 83) */
		reached[1][82] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 185: // STATE 83 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:339 - [event_queues[(webuser-1)]!2,ack_in] (0:0:0 - 1)
		IfNotBlocked
		reached[1][83] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ]]&2)
		{	q_S_check(now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ], II);
		}
#endif
		if (q_full(now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ]))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ]);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((P1 *)_this)->ack_in); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ], 0, 2, ((P1 *)_this)->ack_in, 2);
		if (q_zero(now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ])) { boq = now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ]; };
		_m = 2; goto P999; /* 0 */
	case 186: // STATE 84 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:340 - [state0 = 4] (0:86:2 - 1)
		IfNotBlocked
		reached[1][84] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 4;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(86, 85, 86) */
		reached[1][85] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->completed[1]);
		((P1 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Role:completed[1]", ((int)((P1 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 187: // STATE 86 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:342 - [internal_queue!3] (0:0:0 - 1)
		IfNotBlocked
		reached[1][86] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P1 *)_this)->internal_queue]&2)
		{	q_S_check(((P1 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P1 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P1 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P1 *)_this)->internal_queue, 0, 3, 0, 1);
		if (q_zero(((P1 *)_this)->internal_queue)) { boq = ((P1 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 188: // STATE 87 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:343 - [((state0_transition==10))] (92:0:5 - 1)
		IfNotBlocked
		reached[1][87] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)==10)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(92, 88, 92) */
		reached[1][88] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(92, 89, 92) */
		reached[1][89] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: state0 = 3(92, 90, 92) */
		reached[1][90] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 3;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(92, 91, 92) */
		reached[1][91] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P1 *)_this)->completed[1]);
		((P1 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Role:completed[1]", ((int)((P1 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 189: // STATE 92 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:348 - [internal_queue!2] (0:0:0 - 1)
		IfNotBlocked
		reached[1][92] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P1 *)_this)->internal_queue]&2)
		{	q_S_check(((P1 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P1 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P1 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P1 *)_this)->internal_queue, 0, 2, 0, 1);
		if (q_zero(((P1 *)_this)->internal_queue)) { boq = ((P1 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 190: // STATE 93 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:349 - [((state0_transition==4))] (106:0:5 - 1)
		IfNotBlocked
		reached[1][93] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)==4)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(106, 94, 106) */
		reached[1][94] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(106, 95, 106) */
		reached[1][95] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->completed[1]);
		((P1 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Role:completed[1]", ((int)((P1 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(106, 96, 106) */
		reached[1][96] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: state0 = 9(106, 97, 106) */
		reached[1][97] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 9;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 191: // STATE 98 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:355 - [((WebUser_asCustomer==1))] (142:0:3 - 1)
		IfNotBlocked
		reached[1][98] = 1;
		if (!((((int)now.WebUser_asCustomer)==1)))
			continue;
		/* merge: state0_transition = 7(142, 99, 142) */
		reached[1][99] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 7;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: Logging_chosen = 1(142, 100, 142) */
		reached[1][100] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 1;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: Logging_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->Logging_chosen = 0;
		/* merge: .(goto)(0, 107, 142) */
		reached[1][107] = 1;
		;
		/* merge: .(goto)(0, 138, 142) */
		reached[1][138] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 192: // STATE 101 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:358 - [((WebUser_asCustomer!=1))] (142:0:3 - 1)
		IfNotBlocked
		reached[1][101] = 1;
		if (!((((int)now.WebUser_asCustomer)!=1)))
			continue;
		/* merge: state0_transition = 11(142, 102, 142) */
		reached[1][102] = 1;
		(trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 11;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: Logging_chosen = 1(142, 103, 142) */
		reached[1][103] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 1;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		if (TstOnly) return 1; /* TT */
		/* dead 2: Logging_chosen */  
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->Logging_chosen = 0;
		/* merge: .(goto)(0, 107, 142) */
		reached[1][107] = 1;
		;
		/* merge: .(goto)(0, 138, 142) */
		reached[1][138] = 1;
		;
		_m = 3; goto P999; /* 4 */
	case 193: // STATE 105 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:362 - [assert(0)] (0:0:0 - 1)
		IfNotBlocked
		reached[1][105] = 1;
		spin_assert(0, "0", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 194: // STATE 108 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:364 - [((state0_transition==3))] (142:0:5 - 1)
		IfNotBlocked
		reached[1][108] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)==3)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(142, 109, 142) */
		reached[1][109] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(142, 110, 142) */
		reached[1][110] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->completed[1]);
		((P1 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Role:completed[1]", ((int)((P1 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(142, 111, 142) */
		reached[1][111] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: state0 = 10(142, 112, 142) */
		reached[1][112] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 10;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 138, 142) */
		reached[1][138] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 195: // STATE 113 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:369 - [((state0_transition==6))] (142:0:5 - 1)
		IfNotBlocked
		reached[1][113] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)==6)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(142, 114, 142) */
		reached[1][114] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(142, 115, 142) */
		reached[1][115] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->completed[1]);
		((P1 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Role:completed[1]", ((int)((P1 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(142, 116, 142) */
		reached[1][116] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: state0 = 10(142, 117, 142) */
		reached[1][117] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 10;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 138, 142) */
		reached[1][138] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 196: // STATE 118 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:374 - [((state0_transition==11))] (123:0:5 - 1)
		IfNotBlocked
		reached[1][118] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)==11)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(123, 119, 123) */
		reached[1][119] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(123, 120, 123) */
		reached[1][120] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: state0 = 7(123, 121, 123) */
		reached[1][121] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 7;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(123, 122, 123) */
		reached[1][122] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P1 *)_this)->completed[1]);
		((P1 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Role:completed[1]", ((int)((P1 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 197: // STATE 123 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:379 - [internal_queue!6] (0:0:0 - 1)
		IfNotBlocked
		reached[1][123] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P1 *)_this)->internal_queue]&2)
		{	q_S_check(((P1 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P1 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P1 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 6); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P1 *)_this)->internal_queue, 0, 6, 0, 1);
		if (q_zero(((P1 *)_this)->internal_queue)) { boq = ((P1 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 198: // STATE 124 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:380 - [((state0_transition==9))] (127:0:3 - 1)
		IfNotBlocked
		reached[1][124] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)==9)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(3);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(127, 125, 127) */
		reached[1][125] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(127, 126, 127) */
		reached[1][126] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		_m = 3; goto P999; /* 2 */
	case 199: // STATE 127 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:383 - [event_queues[(webuser-1)]!1,ack_in] (0:0:0 - 1)
		IfNotBlocked
		reached[1][127] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ]]&2)
		{	q_S_check(now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ], II);
		}
#endif
		if (q_full(now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ]))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ]);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		strcat(simvals, ",");
		sprintf(simtmp, "%d", ((P1 *)_this)->ack_in); strcat(simvals, simtmp);		}
#endif
		
		qsend(now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ], 0, 1, ((P1 *)_this)->ack_in, 2);
		if (q_zero(now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ])) { boq = now.event_queues[ Index((((int)((P1 *)_this)->webuser)-1), 15) ]; };
		_m = 2; goto P999; /* 0 */
	case 200: // STATE 128 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:384 - [state0 = 5] (0:130:2 - 1)
		IfNotBlocked
		reached[1][128] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 5;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(130, 129, 130) */
		reached[1][129] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->completed[1]);
		((P1 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Role:completed[1]", ((int)((P1 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 1 */
	case 201: // STATE 130 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:386 - [internal_queue!4] (0:0:0 - 1)
		IfNotBlocked
		reached[1][130] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P1 *)_this)->internal_queue]&2)
		{	q_S_check(((P1 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P1 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P1 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 4); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P1 *)_this)->internal_queue, 0, 4, 0, 1);
		if (q_zero(((P1 *)_this)->internal_queue)) { boq = ((P1 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 202: // STATE 131 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:387 - [((state0_transition==5))] (142:0:5 - 1)
		IfNotBlocked
		reached[1][131] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)==5)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P1 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P1 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(142, 132, 142) */
		reached[1][132] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P1 *)_this)->state0_transition);
		((P1 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Role:state0_transition", ((int)((P1 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(142, 133, 142) */
		reached[1][133] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P1 *)_this)->completed[1]);
		((P1 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Role:completed[1]", ((int)((P1 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(142, 134, 142) */
		reached[1][134] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: state0 = 10(142, 135, 142) */
		reached[1][135] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P1 *)_this)->state0);
		((P1 *)_this)->state0 = 10;
#ifdef VAR_RANGES
		logval("Role:state0", ((int)((P1 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 138, 142) */
		reached[1][138] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 203: // STATE 139 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:395 - [((state0_transition!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[1][139] = 1;
		if (!((((int)((P1 *)_this)->state0_transition)!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 204: // STATE 144 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:399 - [Logging_chosen = 0] (0:149:1 - 2)
		IfNotBlocked
		reached[1][144] = 1;
		(trpt+1)->bup.oval = ((int)((P1 *)_this)->Logging_chosen);
		((P1 *)_this)->Logging_chosen = 0;
#ifdef VAR_RANGES
		logval("Role:Logging_chosen", ((int)((P1 *)_this)->Logging_chosen));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 205: // STATE 145 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:401 - [((state0!=10))] (7:0:0 - 1)
		IfNotBlocked
		reached[1][145] = 1;
		if (!((((int)((P1 *)_this)->state0)!=10)))
			continue;
		/* merge: goto main(0, 146, 7) */
		reached[1][146] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 206: // STATE 152 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:408 - [(0)] (0:0:0 - 2)
		IfNotBlocked
		reached[1][152] = 1;
		if (!(0))
			continue;
		_m = 3; goto P999; /* 0 */
	case 207: // STATE 153 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:409 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[1][153] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Order */
	case 208: // STATE 1 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:172 - [state0 = 1] (0:45:2 - 1)
		IfNotBlocked
		reached[0][1] = 1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P0 *)_this)->state0);
		((P0 *)_this)->state0 = 1;
#ifdef VAR_RANGES
		logval("Order:state0", ((int)((P0 *)_this)->state0));
#endif
		;
		/* merge: state0_transition = 1(45, 2, 45) */
		reached[0][2] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->state0_transition);
		((P0 *)_this)->state0_transition = 1;
#ifdef VAR_RANGES
		logval("Order:state0_transition", ((int)((P0 *)_this)->state0_transition));
#endif
		;
		/* merge: goto transitionFiring(0, 3, 45) */
		reached[0][3] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 209: // STATE 5 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:177 - [current_event = 0] (0:0:1 - 3)
		IfNotBlocked
		reached[0][5] = 1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->current_event);
		((P0 *)_this)->current_event = 0;
#ifdef VAR_RANGES
		logval("Order:current_event", ((int)((P0 *)_this)->current_event));
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 210: // STATE 6 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:179 - [(internal_queue?[current_event])] (0:0:0 - 1)
		IfNotBlocked
		reached[0][6] = 1;
		if (!(
#ifndef XUSAFE
		(!(q_claim[((P0 *)_this)->internal_queue]&1) || q_R_check(((P0 *)_this)->internal_queue, II)) &&
		(!(q_claim[((P0 *)_this)->internal_queue]&2) || q_S_check(((P0 *)_this)->internal_queue, II)) &&
#endif
		not_RV(((P0 *)_this)->internal_queue) && \
		(q_len(((P0 *)_this)->internal_queue) > 0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 211: // STATE 7 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:180 - [internal_queue?current_event] (0:0:1 - 1)
		reached[0][7] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P0 *)_this)->internal_queue]&1)
		{	q_R_check(((P0 *)_this)->internal_queue, II);
		}
#endif
		if (q_zero(((P0 *)_this)->internal_queue))
		{	if (boq != ((P0 *)_this)->internal_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P0 *)_this)->internal_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.oval = ((int)((P0 *)_this)->current_event);
		;
		((P0 *)_this)->current_event = qrecv(((P0 *)_this)->internal_queue, XX-1, 0, 1);
#ifdef VAR_RANGES
		logval("Order:current_event", ((int)((P0 *)_this)->current_event));
#endif
		;
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P0 *)_this)->internal_queue);
			sprintf(simtmp, "%d", ((int)((P0 *)_this)->current_event)); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P0 *)_this)->internal_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 212: // STATE 9 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:182 - [event_queue?current_event,ack_out] (0:0:2 - 1)
		reached[0][9] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P0 *)_this)->event_queue]&1)
		{	q_R_check(((P0 *)_this)->event_queue, II);
		}
#endif
		if (q_zero(((P0 *)_this)->event_queue))
		{	if (boq != ((P0 *)_this)->event_queue) continue;
		} else
		{	if (boq != -1) continue;
		}
		if (q_len(((P0 *)_this)->event_queue) == 0) continue;

		XX=1;
		(trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((int)((P0 *)_this)->current_event);
		(trpt+1)->bup.ovals[1] = ((P0 *)_this)->ack_out;
		;
		((P0 *)_this)->current_event = qrecv(((P0 *)_this)->event_queue, XX-1, 0, 0);
#ifdef VAR_RANGES
		logval("Order:current_event", ((int)((P0 *)_this)->current_event));
#endif
		;
		((P0 *)_this)->ack_out = qrecv(((P0 *)_this)->event_queue, XX-1, 1, 1);
		
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[32];
			sprintf(simvals, "%d?", ((P0 *)_this)->event_queue);
			sprintf(simtmp, "%d", ((int)((P0 *)_this)->current_event)); strcat(simvals, simtmp);
			strcat(simvals, ",");
			sprintf(simtmp, "%d", ((P0 *)_this)->ack_out); strcat(simvals, simtmp);
		}
#endif
		if (q_zero(((P0 *)_this)->event_queue))
		{	boq = -1;
#ifndef NOFAIR
			if (fairness
			&& !(trpt->o_pm&32)
			&& (now._a_t&2)
			&&  now._cnt[now._a_t&1] == II+2)
			{	now._cnt[now._a_t&1] -= 1;
#ifdef VERI
				if (II == 1)
					now._cnt[now._a_t&1] = 1;
#endif
#ifdef DEBUG
			printf("%3ld: proc %d fairness ", depth, II);
			printf("Rule 2: --cnt to %d (%d)\n",
				now._cnt[now._a_t&1], now._a_t);
#endif
				trpt->o_pm |= (32|64);
			}
#endif

		};
		_m = 4; goto P999; /* 0 */
	case 213: // STATE 12 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:186 - [((((state0==2)&&(current_event==1))&&(completed[1]==1)))] (17:0:6 - 1)
		IfNotBlocked
		reached[0][12] = 1;
		if (!((((((int)((P0 *)_this)->state0)==2)&&(((int)((P0 *)_this)->current_event)==1))&&(((int)((P0 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0 */  (trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->state0;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->state0 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P0 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->current_event = 0;
		/* merge: completed[1] = 0(17, 13, 17) */
		reached[0][13] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P0 *)_this)->completed[1]);
		((P0 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Order:completed[1]", ((int)((P0 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(17, 14, 17) */
		reached[0][14] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P0 *)_this)->state0);
		((P0 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Order:state0", ((int)((P0 *)_this)->state0));
#endif
		;
		/* merge: state0 = 3(17, 15, 17) */
		reached[0][15] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P0 *)_this)->state0);
		((P0 *)_this)->state0 = 3;
#ifdef VAR_RANGES
		logval("Order:state0", ((int)((P0 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(17, 16, 17) */
		reached[0][16] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P0 *)_this)->completed[1]);
		((P0 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Order:completed[1]", ((int)((P0 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 214: // STATE 17 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:191 - [internal_queue!2] (0:0:0 - 1)
		IfNotBlocked
		reached[0][17] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P0 *)_this)->internal_queue]&2)
		{	q_S_check(((P0 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P0 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P0 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 2); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P0 *)_this)->internal_queue, 0, 2, 0, 1);
		if (q_zero(((P0 *)_this)->internal_queue)) { boq = ((P0 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 215: // STATE 19 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:193 - [((((state0==4)&&(current_event==3))&&(completed[1]==1)))] (32:0:2 - 1)
		IfNotBlocked
		reached[0][19] = 1;
		if (!((((((int)((P0 *)_this)->state0)==4)&&(((int)((P0 *)_this)->current_event)==3))&&(((int)((P0 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals = grab_ints(2);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->current_event = 0;
		/* merge: state0_transition = 2(0, 20, 32) */
		reached[0][20] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->state0_transition);
		((P0 *)_this)->state0_transition = 2;
#ifdef VAR_RANGES
		logval("Order:state0_transition", ((int)((P0 *)_this)->state0_transition));
#endif
		;
		/* merge: goto Region1region0_label(0, 21, 32) */
		reached[0][21] = 1;
		;
		_m = 3; goto P999; /* 2 */
	case 216: // STATE 22 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:196 - [((((state0==3)&&(current_event==2))&&(completed[1]==1)))] (27:0:6 - 1)
		IfNotBlocked
		reached[0][22] = 1;
		if (!((((((int)((P0 *)_this)->state0)==3)&&(((int)((P0 *)_this)->current_event)==2))&&(((int)((P0 *)_this)->completed[1])==1))))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0 */  (trpt+1)->bup.ovals = grab_ints(6);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->state0;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->state0 = 0;
		if (TstOnly) return 1; /* TT */
		/* dead 1: current_event */  (trpt+1)->bup.ovals[1] = ((P0 *)_this)->current_event;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->current_event = 0;
		/* merge: completed[1] = 0(27, 23, 27) */
		reached[0][23] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P0 *)_this)->completed[1]);
		((P0 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Order:completed[1]", ((int)((P0 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(27, 24, 27) */
		reached[0][24] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P0 *)_this)->state0);
		((P0 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Order:state0", ((int)((P0 *)_this)->state0));
#endif
		;
		/* merge: state0 = 4(27, 25, 27) */
		reached[0][25] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P0 *)_this)->state0);
		((P0 *)_this)->state0 = 4;
#ifdef VAR_RANGES
		logval("Order:state0", ((int)((P0 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(27, 26, 27) */
		reached[0][26] = 1;
		(trpt+1)->bup.ovals[5] = ((int)((P0 *)_this)->completed[1]);
		((P0 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Order:completed[1]", ((int)((P0 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 217: // STATE 27 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:201 - [internal_queue!3] (0:0:0 - 1)
		IfNotBlocked
		reached[0][27] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P0 *)_this)->internal_queue]&2)
		{	q_S_check(((P0 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P0 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P0 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 3); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P0 *)_this)->internal_queue, 0, 3, 0, 1);
		if (q_zero(((P0 *)_this)->internal_queue)) { boq = ((P0 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 218: // STATE 33 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:209 - [((state0_transition==1))] (38:0:5 - 1)
		IfNotBlocked
		reached[0][33] = 1;
		if (!((((int)((P0 *)_this)->state0_transition)==1)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(38, 34, 38) */
		reached[0][34] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->state0_transition);
		((P0 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Order:state0_transition", ((int)((P0 *)_this)->state0_transition));
#endif
		;
		/* merge: state0 = 0(38, 35, 38) */
		reached[0][35] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P0 *)_this)->state0);
		((P0 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Order:state0", ((int)((P0 *)_this)->state0));
#endif
		;
		/* merge: state0 = 2(38, 36, 38) */
		reached[0][36] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P0 *)_this)->state0);
		((P0 *)_this)->state0 = 2;
#ifdef VAR_RANGES
		logval("Order:state0", ((int)((P0 *)_this)->state0));
#endif
		;
		/* merge: completed[1] = 1(38, 37, 38) */
		reached[0][37] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P0 *)_this)->completed[1]);
		((P0 *)_this)->completed[1] = 1;
#ifdef VAR_RANGES
		logval("Order:completed[1]", ((int)((P0 *)_this)->completed[1]));
#endif
		;
		_m = 3; goto P999; /* 4 */
	case 219: // STATE 38 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:214 - [internal_queue!1] (0:0:0 - 1)
		IfNotBlocked
		reached[0][38] = 1;
		
#if !defined(XUSAFE) && !defined(NOREDUCE)
		if (q_claim[((P0 *)_this)->internal_queue]&2)
		{	q_S_check(((P0 *)_this)->internal_queue, II);
		}
#endif
		if (q_full(((P0 *)_this)->internal_queue))
			continue;
#ifdef HAS_CODE
		if (readtrail && gui) {
			char simtmp[64];
			sprintf(simvals, "%d!", ((P0 *)_this)->internal_queue);
		sprintf(simtmp, "%d", 1); strcat(simvals, simtmp);		}
#endif
		
		qsend(((P0 *)_this)->internal_queue, 0, 1, 0, 1);
		if (q_zero(((P0 *)_this)->internal_queue)) { boq = ((P0 *)_this)->internal_queue; };
		_m = 2; goto P999; /* 0 */
	case 220: // STATE 39 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:215 - [((state0_transition==2))] (50:0:5 - 1)
		IfNotBlocked
		reached[0][39] = 1;
		if (!((((int)((P0 *)_this)->state0_transition)==2)))
			continue;
		if (TstOnly) return 1; /* TT */
		/* dead 1: state0_transition */  (trpt+1)->bup.ovals = grab_ints(5);
		(trpt+1)->bup.ovals[0] = ((P0 *)_this)->state0_transition;
#ifdef HAS_CODE
		if (!readtrail)
#endif
			((P0 *)_this)->state0_transition = 0;
		/* merge: state0_transition = 0(50, 40, 50) */
		reached[0][40] = 1;
		(trpt+1)->bup.ovals[1] = ((int)((P0 *)_this)->state0_transition);
		((P0 *)_this)->state0_transition = 0;
#ifdef VAR_RANGES
		logval("Order:state0_transition", ((int)((P0 *)_this)->state0_transition));
#endif
		;
		/* merge: completed[1] = 0(50, 41, 50) */
		reached[0][41] = 1;
		(trpt+1)->bup.ovals[2] = ((int)((P0 *)_this)->completed[1]);
		((P0 *)_this)->completed[1] = 0;
#ifdef VAR_RANGES
		logval("Order:completed[1]", ((int)((P0 *)_this)->completed[1]));
#endif
		;
		/* merge: state0 = 0(50, 42, 50) */
		reached[0][42] = 1;
		(trpt+1)->bup.ovals[3] = ((int)((P0 *)_this)->state0);
		((P0 *)_this)->state0 = 0;
#ifdef VAR_RANGES
		logval("Order:state0", ((int)((P0 *)_this)->state0));
#endif
		;
		/* merge: state0 = 5(50, 43, 50) */
		reached[0][43] = 1;
		(trpt+1)->bup.ovals[4] = ((int)((P0 *)_this)->state0);
		((P0 *)_this)->state0 = 5;
#ifdef VAR_RANGES
		logval("Order:state0", ((int)((P0 *)_this)->state0));
#endif
		;
		/* merge: .(goto)(0, 46, 50) */
		reached[0][46] = 1;
		;
		_m = 3; goto P999; /* 5 */
	case 221: // STATE 47 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:223 - [((state0_transition!=0))] (0:0:0 - 1)
		IfNotBlocked
		reached[0][47] = 1;
		if (!((((int)((P0 *)_this)->state0_transition)!=0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 222: // STATE 52 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:228 - [((state0!=5))] (5:0:0 - 1)
		IfNotBlocked
		reached[0][52] = 1;
		if (!((((int)((P0 *)_this)->state0)!=5)))
			continue;
		/* merge: goto main(0, 53, 5) */
		reached[0][53] = 1;
		;
		_m = 3; goto P999; /* 1 */
	case 223: // STATE 59 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:235 - [(0)] (0:0:0 - 2)
		IfNotBlocked
		reached[0][59] = 1;
		if (!(0))
			continue;
		_m = 3; goto P999; /* 0 */
	case 224: // STATE 60 - cache\\promella_initializations\\algorithm2\\initialiazation_127_CustomerProfile_freeDelivery_false.pml:236 - [-end-] (0:0:0 - 1)
		IfNotBlocked
		reached[0][60] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

