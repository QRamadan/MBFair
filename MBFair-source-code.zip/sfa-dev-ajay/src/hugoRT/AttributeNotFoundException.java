package hugoRT;

public class AttributeNotFoundException extends Exception {

}
